export interface SchoolInfo {
  name: string;
  urduName: string;
  principalName: string;
  phone: string;
  rawPhone: string;
  whatsapp: string;
  address: string;
  cityTehsil: string;
  emisCode: string;
  affiliation: string;
  registration: string;
  email: string;
  admissionSession: string;
  admissionDeadline: string;
  schoolTimingSummer: string;
  schoolTimingWinter: string;
  photoUrl: string;
  principalPhotoUrl: string;
}

export interface ClassAcademicItem {
  id: string;
  title: string;
  urduTitle?: string;
  ageGroup: string;
  category: 'pre-primary' | 'primary' | 'middle' | 'high';
  curriculum: string;
  subjects: string[];
  description: string;
  features: string[];
  isHighlight?: boolean;
}

export interface FacilityItem {
  id: string;
  title: string;
  urduTitle?: string;
  description: string;
  iconName: string;
  tag: string;
  bulletPoints: string[];
}

export interface NoticeItem {
  id: string;
  title: string;
  urduTitle?: string;
  date: string;
  category: 'Admissions' | 'Exams' | 'Holidays' | 'Results' | 'Meetings' | 'Events' | 'General';
  description: string;
  isImportant?: boolean;
  fileAttachment?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Campus' | 'Science & Lab' | 'Classrooms' | 'Activities' | 'Sports' | 'Events';
  imageUrl: string;
  caption: string;
  date?: string;
}

export interface AchievementItem {
  id: string;
  title: string;
  studentName?: string;
  fatherName?: string;
  marks?: string;
  totalMarks?: string;
  year: string;
  category: 'Board Exam' | 'Science Olympiad' | 'Sports' | 'Co-Curricular';
  description: string;
  badge: string;
}

export interface SchoolStat {
  id: string;
  value: string;
  label: string;
  urduLabel?: string;
  description: string;
}

export interface AdmissionApplication {
  id: string;
  referenceNumber: string;
  studentFullName: string;
  fatherName: string;
  motherName: string;
  guardianName: string;
  dob: string;
  gender: 'Male' | 'Female';
  classApplyingFor: string;
  previousSchool: string;
  previousClass: string;
  parentPhone: string;
  whatsappNumber: string;
  email: string;
  address: string;
  city: string;
  bFormNumber: string;
  additionalNotes: string;
  submittedAt: string;
  status: 'Pending Review' | 'Approved' | 'Interview Scheduled' | 'Admission Granted';
}

export interface ContactMessage {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
  submittedAt: string;
}
