/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SchoolProvider } from './context/SchoolContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AdmissionsOpen } from './components/AdmissionsOpen';
import { AboutUs } from './components/AboutUs';
import { PrincipalMessage } from './components/PrincipalMessage';
import { Academics } from './components/Academics';
import { Facilities } from './components/Facilities';
import { Achievements } from './components/Achievements';
import { Gallery } from './components/Gallery';
import { NoticeBoard } from './components/NoticeBoard';
import { OnlineAdmissionForm } from './components/OnlineAdmissionForm';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { EditSchoolModal } from './components/EditSchoolModal';
import { AdmissionsAdminModal } from './components/AdmissionsAdminModal';
import { ImageLightboxModal } from './components/ImageLightboxModal';

export default function App() {
  return (
    <SchoolProvider>
      <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
        {/* Navigation Bar */}
        <Navbar />

        {/* Main Content Sections */}
        <main className="flex-1">
          {/* 1. Hero Section */}
          <Hero />

          {/* 2. Admissions Open Callout & Key Details */}
          <AdmissionsOpen />

          {/* 3. About Us (Introduction, Mission, Vision, Values, Why Choose Us) */}
          <AboutUs />

          {/* 4. Principal Message (Jam Naseem) */}
          <PrincipalMessage />

          {/* 5. Classes / Academics (Play Group to Grade 10 Matric Science) */}
          <Academics />

          {/* 6. Facilities (10 modern facilities cards) */}
          <Facilities />

          {/* 7. Achievements & Key Statistics (Board Results & Honors) */}
          <Achievements />

          {/* 8. School Gallery (Showcasing real school building photo) */}
          <Gallery />

          {/* 9. Notice Board / Circulars */}
          <NoticeBoard />

          {/* 10. Online Admission Application Form */}
          <OnlineAdmissionForm />

          {/* 11. Contact Us & Campus Map */}
          <ContactSection />
        </main>

        {/* Footer */}
        <Footer />

        {/* Floating Actions (Sticky WhatsApp button, Back to Top, Apply Pill) */}
        <FloatingActions />

        {/* Interactive Modals */}
        <EditSchoolModal />
        <AdmissionsAdminModal />
        <ImageLightboxModal />
      </div>
    </SchoolProvider>
  );
}
