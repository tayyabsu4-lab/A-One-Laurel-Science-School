import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  SchoolInfo,
  ClassAcademicItem,
  FacilityItem,
  NoticeItem,
  GalleryItem,
  AchievementItem,
  SchoolStat,
  AdmissionApplication,
} from '../types';
import {
  initialSchoolInfo,
  initialClasses,
  initialFacilities,
  initialNotices,
  initialGallery,
  initialStats,
  initialAchievements,
} from '../data/schoolData';

interface SchoolContextType {
  schoolInfo: SchoolInfo;
  updateSchoolInfo: (info: Partial<SchoolInfo>) => void;
  resetSchoolInfo: () => void;
  setSchoolPhoto: (photoDataUrl: string) => void;
  setPrincipalPhoto: (photoDataUrl: string) => void;
  
  classes: ClassAcademicItem[];
  facilities: FacilityItem[];
  notices: NoticeItem[];
  addNotice: (notice: Omit<NoticeItem, 'id'>) => void;
  
  gallery: GalleryItem[];
  addGalleryImage: (item: Omit<GalleryItem, 'id'>) => void;
  
  stats: SchoolStat[];
  updateStat: (id: string, value: string) => void;
  
  achievements: AchievementItem[];
  
  admissions: AdmissionApplication[];
  submitAdmission: (app: Omit<AdmissionApplication, 'id' | 'referenceNumber' | 'submittedAt' | 'status'>) => AdmissionApplication;
  updateAdmissionStatus: (id: string, status: AdmissionApplication['status']) => void;
  deleteAdmission: (id: string) => void;
  
  isEditModalOpen: boolean;
  setIsEditModalOpen: (open: boolean) => void;
  isAdminModalOpen: boolean;
  setIsAdminModalOpen: (open: boolean) => void;
  activeImagePreview: string | null;
  setActiveImagePreview: (url: string | null) => void;
}

const STORAGE_KEYS = {
  SCHOOL_INFO: 'aolss_school_info_v1',
  ADMISSIONS: 'aolss_admissions_v1',
  GALLERY: 'aolss_gallery_v1',
  NOTICES: 'aolss_notices_v1',
  STATS: 'aolss_stats_v1',
};

const SchoolContext = createContext<SchoolContextType | undefined>(undefined);

export const SchoolProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [schoolInfo, setSchoolInfoState] = useState<SchoolInfo>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SCHOOL_INFO);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.photoUrl || parsed.photoUrl.includes('.svg')) {
          parsed.photoUrl = '/IMG_E7145.JPG';
        }
        return { ...initialSchoolInfo, ...parsed };
      }
    } catch (e) {
      console.error('Error loading school info:', e);
    }
    return initialSchoolInfo;
  });

  const [classes] = useState<ClassAcademicItem[]>(initialClasses);
  const [facilities] = useState<FacilityItem[]>(initialFacilities);

  const [notices, setNotices] = useState<NoticeItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.NOTICES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading notices:', e);
    }
    return initialNotices;
  });

  const [gallery, setGallery] = useState<GalleryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GALLERY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // If the cached gallery does not have the 4 official photos, reset to initialGallery + user uploads
          const userUploaded = parsed.filter((item: GalleryItem) => !item.id.startsWith('gal-') || parseInt(item.id.replace('gal-', ''), 10) > 100);
          const hasPhoto4 = parsed.some((item: GalleryItem) => item.imageUrl?.includes('photo-4') || item.title?.includes('Photo 4'));
          if (!hasPhoto4) {
            return [...userUploaded, ...initialGallery];
          }
          return parsed.map((item: GalleryItem) => {
            if (item.imageUrl && item.imageUrl.includes('.svg')) {
              return { ...item, imageUrl: '/photo-1-full-campus.jpg' };
            }
            return item;
          });
        }
      }
    } catch (e) {
      console.error('Error loading gallery:', e);
    }
    return initialGallery;
  });

  const [stats, setStats] = useState<SchoolStat[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STATS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading stats:', e);
    }
    return initialStats;
  });

  const [achievements] = useState<AchievementItem[]>(initialAchievements);

  const [admissions, setAdmissions] = useState<AdmissionApplication[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ADMISSIONS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading admissions:', e);
    }
    return [];
  });

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [activeImagePreview, setActiveImagePreview] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SCHOOL_INFO, JSON.stringify(schoolInfo));
    } catch (e) {
      console.error('Failed to save school info:', e);
    }
  }, [schoolInfo]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ADMISSIONS, JSON.stringify(admissions));
    } catch (e) {
      console.error('Failed to save admissions:', e);
    }
  }, [admissions]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(gallery));
    } catch (e) {
      console.error('Failed to save gallery:', e);
    }
  }, [gallery]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(notices));
    } catch (e) {
      console.error('Failed to save notices:', e);
    }
  }, [notices]);

  const updateSchoolInfo = (info: Partial<SchoolInfo>) => {
    setSchoolInfoState((prev) => {
      const updated = { ...prev, ...info };
      if (info.phone) {
        updated.rawPhone = info.phone.replace(/[^0-9]/g, '');
      }
      return updated;
    });
  };

  const resetSchoolInfo = () => {
    setSchoolInfoState(initialSchoolInfo);
    try {
      localStorage.removeItem(STORAGE_KEYS.SCHOOL_INFO);
    } catch (e) {
      console.error(e);
    }
  };

  const setSchoolPhoto = (photoDataUrl: string) => {
    setSchoolInfoState((prev) => ({ ...prev, photoUrl: photoDataUrl }));
    // Also add to gallery if not present
    setGallery((prev) => [
      {
        id: 'gal-user-' + Date.now(),
        title: 'Uploaded Official School Photo',
        category: 'Campus',
        imageUrl: photoDataUrl,
        caption: 'Verified real photograph of A One Laurel Science School campus and signboard.',
        date: 'Current Asset',
      },
      ...prev,
    ]);
  };

  const setPrincipalPhoto = (photoDataUrl: string) => {
    setSchoolInfoState((prev) => ({ ...prev, principalPhotoUrl: photoDataUrl }));
  };

  const addNotice = (notice: Omit<NoticeItem, 'id'>) => {
    const newNotice: NoticeItem = {
      ...notice,
      id: 'not-' + Date.now(),
    };
    setNotices((prev) => [newNotice, ...prev]);
  };

  const addGalleryImage = (item: Omit<GalleryItem, 'id'>) => {
    const newItem: GalleryItem = {
      ...item,
      id: 'gal-' + Date.now(),
    };
    setGallery((prev) => [newItem, ...prev]);
  };

  const updateStat = (id: string, value: string) => {
    setStats((prev) =>
      prev.map((stat) => (stat.id === id ? { ...stat, value } : stat))
    );
  };

  const submitAdmission = (
    appData: Omit<AdmissionApplication, 'id' | 'referenceNumber' | 'submittedAt' | 'status'>
  ): AdmissionApplication => {
    const randomCode = Math.floor(1000 + Math.random() * 9000);
    const newApp: AdmissionApplication = {
      ...appData,
      id: 'app-' + Date.now(),
      referenceNumber: `AOLSS-2026-${randomCode}`,
      submittedAt: new Date().toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      status: 'Pending Review',
    };

    setAdmissions((prev) => [newApp, ...prev]);
    return newApp;
  };

  const updateAdmissionStatus = (id: string, status: AdmissionApplication['status']) => {
    setAdmissions((prev) =>
      prev.map((app) => (app.id === id ? { ...app, status } : app))
    );
  };

  const deleteAdmission = (id: string) => {
    setAdmissions((prev) => prev.filter((app) => app.id !== id));
  };

  return (
    <SchoolContext.Provider
      value={{
        schoolInfo,
        updateSchoolInfo,
        resetSchoolInfo,
        setSchoolPhoto,
        setPrincipalPhoto,
        classes,
        facilities,
        notices,
        addNotice,
        gallery,
        addGalleryImage,
        stats,
        updateStat,
        achievements,
        admissions,
        submitAdmission,
        updateAdmissionStatus,
        deleteAdmission,
        isEditModalOpen,
        setIsEditModalOpen,
        isAdminModalOpen,
        setIsAdminModalOpen,
        activeImagePreview,
        setActiveImagePreview,
      }}
    >
      {children}
    </SchoolContext.Provider>
  );
};

export const useSchool = () => {
  const context = useContext(SchoolContext);
  if (!context) {
    throw new Error('useSchool must be used within a SchoolProvider');
  }
  return context;
};
