import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  FileText,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Layers,
  CheckCircle2,
  AlertCircle,
  Printer,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building,
} from 'lucide-react';
import { AdmissionApplication } from '../types';

export const OnlineAdmissionForm: React.FC = () => {
  const { schoolInfo, submitAdmission } = useSchool();

  // Form State
  const [formData, setFormData] = useState({
    studentFullName: '',
    fatherName: '',
    motherName: '',
    guardianName: '',
    dob: '',
    gender: 'Male' as 'Male' | 'Female',
    classApplyingFor: 'Grade 9 (Matric Science)',
    previousSchool: '',
    previousClass: '',
    parentPhone: '',
    whatsappNumber: '',
    email: '',
    address: '',
    city: 'Jahanian',
    bFormNumber: '',
    additionalNotes: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedApp, setSubmittedApp] = useState<AdmissionApplication | null>(null);

  const availableClasses = [
    'Play Group',
    'Nursery',
    'Prep (Kindergarten)',
    'Grade 1',
    'Grade 2',
    'Grade 3',
    'Grade 4',
    'Grade 5',
    'Grade 6',
    'Grade 7',
    'Grade 8',
    'Grade 9 (Matric Science)',
    'Grade 10 (Matric Science)',
  ];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.studentFullName.trim()) {
      errs.studentFullName = 'Student Full Name is required';
    }
    if (!formData.fatherName.trim()) {
      errs.fatherName = 'Father Name is required';
    }
    if (!formData.dob) {
      errs.dob = 'Date of birth is required';
    }
    if (!formData.parentPhone.trim()) {
      errs.parentPhone = 'Parent phone number is required';
    } else if (formData.parentPhone.replace(/[^0-9]/g, '').length < 10) {
      errs.parentPhone = 'Please enter a valid phone number';
    }
    if (!formData.whatsappNumber.trim()) {
      errs.whatsappNumber = 'WhatsApp contact number is required';
    }
    if (!formData.address.trim()) {
      errs.address = 'Residential address is required';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      const firstErrorKey = Object.keys(errors)[0];
      const el = document.getElementById(`field-${firstErrorKey}`);
      if (el) el.focus();
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const created = submitAdmission({
        studentFullName: formData.studentFullName.trim(),
        fatherName: formData.fatherName.trim(),
        motherName: formData.motherName.trim(),
        guardianName: formData.guardianName.trim(),
        dob: formData.dob,
        gender: formData.gender,
        classApplyingFor: formData.classApplyingFor,
        previousSchool: formData.previousSchool.trim(),
        previousClass: formData.previousClass.trim(),
        parentPhone: formData.parentPhone.trim(),
        whatsappNumber: formData.whatsappNumber.trim(),
        email: formData.email.trim(),
        address: formData.address.trim(),
        city: formData.city.trim(),
        bFormNumber: formData.bFormNumber.trim(),
        additionalNotes: formData.additionalNotes.trim(),
      });

      setSubmittedApp(created);
      setIsSubmitting(false);

      // Reset form fields
      setFormData({
        studentFullName: '',
        fatherName: '',
        motherName: '',
        guardianName: '',
        dob: '',
        gender: 'Male',
        classApplyingFor: 'Grade 9 (Matric Science)',
        previousSchool: '',
        previousClass: '',
        parentPhone: '',
        whatsappNumber: '',
        email: '',
        address: '',
        city: 'Jahanian',
        bFormNumber: '',
        additionalNotes: '',
      });
    }, 400);
  };

  const handlePrintSlip = () => {
    window.print();
  };

  return (
    <section id="admission-form" className="py-16 sm:py-24 bg-slate-50 border-t border-slate-200 relative">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#1e293b] text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <FileText className="w-4 h-4 text-yellow-400" />
            <span>Online Registration Desk</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Online Admission Application Form
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600">
            Apply online for Session {schoolInfo.admissionSession}. Fill in the details below to secure early admission consideration.
          </p>
        </div>

        {/* Success / Admission Slip Modal / Card */}
        {submittedApp && (
          <div className="mb-12 bg-emerald-50 border-2 border-emerald-500 rounded-lg p-6 sm:p-8 shadow-xl text-slate-900 animate-in fade-in duration-300">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-6 border-b border-emerald-200">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-emerald-900">
                    Application Submitted Successfully!
                  </h3>
                  <p className="text-sm text-emerald-700">
                    Your application has been received and logged at the school administration office.
                  </p>
                </div>
              </div>
              <button
                onClick={handlePrintSlip}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider shadow-md transition-colors"
              >
                <Printer className="w-4 h-4 text-yellow-400" />
                <span>Print Application Slip</span>
              </button>
            </div>

            {/* Slip Details */}
            <div className="my-6 bg-white rounded-lg p-6 border border-emerald-200 shadow-xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                <div>
                  <span className="text-xs text-slate-400 block font-mono">Reference Tracking Number</span>
                  <span className="text-xl font-extrabold font-mono text-[#1e293b]">
                    {submittedApp.referenceNumber}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Date of Submission</span>
                  <span className="text-xs font-bold text-slate-700">{submittedApp.submittedAt}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-xs text-slate-500 block">Student Name:</span>
                  <span className="font-bold text-slate-900">{submittedApp.studentFullName}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Father / Guardian:</span>
                  <span className="font-bold text-slate-900">{submittedApp.fatherName}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Class Applied:</span>
                  <span className="font-bold text-blue-900">{submittedApp.classApplyingFor}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Gender & DOB:</span>
                  <span className="font-medium text-slate-800">{submittedApp.gender} | {submittedApp.dob}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Parent Phone:</span>
                  <span className="font-bold text-slate-900">{submittedApp.parentPhone}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Application Status:</span>
                  <span className="inline-block px-2 py-0.5 rounded bg-yellow-100 text-yellow-900 text-xs font-bold uppercase">
                    {submittedApp.status}
                  </span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 text-xs text-slate-600">
                <p>
                  <strong>Next Steps:</strong> Please visit <strong>{schoolInfo.name}</strong> at <strong>{schoolInfo.address}</strong> with your original B-Form, 2 photographs, and previous school report card to finalize admission test and interview.
                </p>
                <p className="mt-1 text-slate-500">
                  School Phone: {schoolInfo.phone} | Principal: {schoolInfo.principalName}
                </p>
              </div>
            </div>

            <button
              onClick={() => setSubmittedApp(null)}
              className="text-xs font-bold text-emerald-800 hover:text-emerald-950 underline uppercase tracking-wider"
            >
              Submit Another Application Form →
            </button>
          </div>
        )}

        {/* The Form Card */}
        <div className="bg-white rounded-lg p-6 sm:p-10 border-t-4 border-yellow-500 border-x border-b border-slate-200 shadow-md">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* 1. Student Personal Information */}
            <div>
              <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-200">
                <span className="w-2.5 h-2.5 bg-yellow-500 rounded-full inline-block"></span>
                <h3 className="text-base font-bold text-blue-900 uppercase tracking-wider">
                  1. Student Personal Information
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Full Name */}
                <div className="sm:col-span-2">
                  <label htmlFor="field-studentFullName" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Student Full Name *
                  </label>
                  <input
                    id="field-studentFullName"
                    type="text"
                    required
                    value={formData.studentFullName}
                    onChange={(e) => setFormData({ ...formData, studentFullName: e.target.value })}
                    placeholder="e.g. Muhammad Ahmad or Fatima Zahra"
                    className={`w-full px-4 py-2.5 rounded border bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 ${
                      errors.studentFullName ? 'border-red-500 ring-red-200' : 'border-slate-300'
                    }`}
                  />
                  {errors.studentFullName && (
                    <p className="text-xs text-red-600 mt-1">{errors.studentFullName}</p>
                  )}
                </div>

                {/* Class Applying For */}
                <div>
                  <label htmlFor="field-classApplyingFor" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Class Applying For *
                  </label>
                  <select
                    id="field-classApplyingFor"
                    value={formData.classApplyingFor}
                    onChange={(e) => setFormData({ ...formData, classApplyingFor: e.target.value })}
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  >
                    {availableClasses.map((cls) => (
                      <option key={cls} value={cls}>
                        {cls}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Date of Birth */}
                <div>
                  <label htmlFor="field-dob" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Date of Birth *
                  </label>
                  <input
                    id="field-dob"
                    type="date"
                    required
                    value={formData.dob}
                    onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                    className={`w-full px-4 py-2.5 rounded border bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 ${
                      errors.dob ? 'border-red-500 ring-red-200' : 'border-slate-300'
                    }`}
                  />
                  {errors.dob && <p className="text-xs text-red-600 mt-1">{errors.dob}</p>}
                </div>

                {/* Gender */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Gender *
                  </label>
                  <div className="flex items-center gap-4 py-2">
                    <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                      <input
                        type="radio"
                        name="gender"
                        value="Male"
                        checked={formData.gender === 'Male'}
                        onChange={() => setFormData({ ...formData, gender: 'Male' })}
                        className="text-yellow-600 focus:ring-yellow-500"
                      />
                      <span>Male / Boy</span>
                    </label>
                    <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                      <input
                        type="radio"
                        name="gender"
                        value="Female"
                        checked={formData.gender === 'Female'}
                        onChange={() => setFormData({ ...formData, gender: 'Female' })}
                        className="text-yellow-600 focus:ring-yellow-500"
                      />
                      <span>Female / Girl</span>
                    </label>
                  </div>
                </div>

                {/* B-Form # */}
                <div>
                  <label htmlFor="field-bFormNumber" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    NADRA B-Form Number (Optional)
                  </label>
                  <input
                    id="field-bFormNumber"
                    type="text"
                    value={formData.bFormNumber}
                    onChange={(e) => setFormData({ ...formData, bFormNumber: e.target.value })}
                    placeholder="e.g. 36104-XXXXXXX-X"
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  />
                </div>
              </div>
            </div>

            {/* 2. Parent & Guardian Details */}
            <div>
              <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-200">
                <span className="w-2.5 h-2.5 bg-yellow-500 rounded-full inline-block"></span>
                <h3 className="text-base font-bold text-blue-900 uppercase tracking-wider">
                  2. Parent & Guardian Details
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="field-fatherName" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Father Name *
                  </label>
                  <input
                    id="field-fatherName"
                    type="text"
                    required
                    value={formData.fatherName}
                    onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                    placeholder="Father's full name"
                    className={`w-full px-4 py-2.5 rounded border bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 ${
                      errors.fatherName ? 'border-red-500 ring-red-200' : 'border-slate-300'
                    }`}
                  />
                  {errors.fatherName && (
                    <p className="text-xs text-red-600 mt-1">{errors.fatherName}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="field-motherName" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Mother Name
                  </label>
                  <input
                    id="field-motherName"
                    type="text"
                    value={formData.motherName}
                    onChange={(e) => setFormData({ ...formData, motherName: e.target.value })}
                    placeholder="Mother's name"
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  />
                </div>

                <div>
                  <label htmlFor="field-guardianName" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Guardian Name (if other than Father)
                  </label>
                  <input
                    id="field-guardianName"
                    type="text"
                    value={formData.guardianName}
                    onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                    placeholder="Guardian name & relationship"
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  />
                </div>
              </div>
            </div>

            {/* 3. Contact & Address Information */}
            <div>
              <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-200">
                <span className="w-2.5 h-2.5 bg-yellow-500 rounded-full inline-block"></span>
                <h3 className="text-base font-bold text-blue-900 uppercase tracking-wider">
                  3. Contact & Address Information
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="field-parentPhone" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Parent Contact Phone Number *
                  </label>
                  <input
                    id="field-parentPhone"
                    type="tel"
                    required
                    value={formData.parentPhone}
                    onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                    placeholder="e.g. 0347-1234567"
                    className={`w-full px-4 py-2.5 rounded border bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 ${
                      errors.parentPhone ? 'border-red-500 ring-red-200' : 'border-slate-300'
                    }`}
                  />
                  {errors.parentPhone && (
                    <p className="text-xs text-red-600 mt-1">{errors.parentPhone}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="field-whatsappNumber" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    WhatsApp Number (for School Updates) *
                  </label>
                  <input
                    id="field-whatsappNumber"
                    type="tel"
                    required
                    value={formData.whatsappNumber}
                    onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                    placeholder="e.g. 0347-8856741"
                    className={`w-full px-4 py-2.5 rounded border bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 ${
                      errors.whatsappNumber ? 'border-red-500 ring-red-200' : 'border-slate-300'
                    }`}
                  />
                  {errors.whatsappNumber && (
                    <p className="text-xs text-red-600 mt-1">{errors.whatsappNumber}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="field-email" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Email Address (Optional)
                  </label>
                  <input
                    id="field-email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="parent@example.com"
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="field-address" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Residential Address *
                  </label>
                  <input
                    id="field-address"
                    type="text"
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Village / Mohallah, Street, Adda / Area"
                    className={`w-full px-4 py-2.5 rounded border bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 ${
                      errors.address ? 'border-red-500 ring-red-200' : 'border-slate-300'
                    }`}
                  />
                  {errors.address && (
                    <p className="text-xs text-red-600 mt-1">{errors.address}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="field-city" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Tehsil / City
                  </label>
                  <input
                    id="field-city"
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="Jahanian / Khanewal"
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  />
                </div>
              </div>
            </div>

            {/* 4. Previous Academic Background */}
            <div>
              <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-200">
                <span className="w-2.5 h-2.5 bg-yellow-500 rounded-full inline-block"></span>
                <h3 className="text-base font-bold text-blue-900 uppercase tracking-wider">
                  4. Previous Academic Background
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="field-previousSchool" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Previous School Name (if any)
                  </label>
                  <input
                    id="field-previousSchool"
                    type="text"
                    value={formData.previousSchool}
                    onChange={(e) => setFormData({ ...formData, previousSchool: e.target.value })}
                    placeholder="Previous school attended"
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  />
                </div>

                <div>
                  <label htmlFor="field-previousClass" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Previous Class & Marks Obtained
                  </label>
                  <input
                    id="field-previousClass"
                    type="text"
                    value={formData.previousClass}
                    onChange={(e) => setFormData({ ...formData, previousClass: e.target.value })}
                    placeholder="e.g. 8th Class - 480/550"
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="field-additionalNotes" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Additional Remarks / Specific Health or Learning Notes
                  </label>
                  <textarea
                    id="field-additionalNotes"
                    rows={2}
                    value={formData.additionalNotes}
                    onChange={(e) => setFormData({ ...formData, additionalNotes: e.target.value })}
                    placeholder="Any special remarks, sibling discounts, or medical notes..."
                    className="w-full px-4 py-2.5 rounded border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                  />
                </div>
              </div>
            </div>

            {/* Declaration & Submit Button */}
            <div className="pt-4 border-t border-slate-200">
              <div className="flex items-start gap-2.5 mb-6 text-xs text-slate-600 bg-slate-50 p-4 rounded border border-slate-200">
                <ShieldCheck className="w-4 h-4 text-[#1e293b] mt-0.5 flex-shrink-0" />
                <span>
                  <strong>Declaration:</strong> I solemnly affirm that the information provided in this admission form is true and accurate. I agree to abide by the rules, code of conduct, and academic guidelines of {schoolInfo.name}.
                </span>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-slate-500">
                  <span>* Required fields must be completed.</span>
                </div>

                <button
                  id="submit-admission-form-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3 rounded font-bold text-xs uppercase tracking-wider text-[#1e293b] bg-yellow-500 hover:bg-yellow-400 disabled:opacity-50 shadow-md transition-all hover:scale-[1.02]"
                >
                  {isSubmitting ? (
                    <span>Processing Application...</span>
                  ) : (
                    <>
                      <span>Submit Application</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
