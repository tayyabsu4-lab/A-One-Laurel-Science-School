import React, { useRef } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Quote,
  GraduationCap,
  Award,
  Upload,
  User,
  Heart,
  CheckCircle,
} from 'lucide-react';

export const PrincipalMessage: React.FC = () => {
  const { schoolInfo, setPrincipalPhoto } = useSchool();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePrincipalPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPrincipalPhoto(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="principal" className="py-16 sm:py-20 bg-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left Column: Principal Photo / Avatar with Professional Polish Deep Slate styling */}
            <div className="lg:col-span-4 bg-[#1e293b] p-6 sm:p-8 text-white flex flex-col justify-between relative overflow-hidden border-b-4 lg:border-b-0 lg:border-r-4 border-yellow-500">
              <div>
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-slate-800 text-yellow-400 text-xs font-bold uppercase tracking-wider mb-6 border border-yellow-500/30">
                  <Award className="w-3.5 h-3.5" />
                  <span>Principal's Desk</span>
                </div>

                {/* Photo container matching design: rounded-full with border */}
                <div className="relative mx-auto lg:mx-0 w-36 h-36 rounded-full overflow-hidden bg-slate-800 border-4 border-yellow-500 shadow-md group flex items-center justify-center">
                  {schoolInfo.principalPhotoUrl ? (
                    <img
                      id="principal-photo-img"
                      src={schoolInfo.principalPhotoUrl}
                      alt={`Principal ${schoolInfo.principalName}`}
                      className="w-full h-full object-cover object-center"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-center p-4 text-slate-300">
                      <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center mb-1 text-yellow-400">
                        <User className="w-6 h-6" />
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300">Photo</span>
                    </div>
                  )}

                  {/* Upload overlay */}
                  <label
                    htmlFor="principal-photo-input"
                    className="absolute inset-0 bg-slate-950/75 backdrop-blur-2xs opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center cursor-pointer text-white text-[11px] font-bold uppercase tracking-wider"
                  >
                    <Upload className="w-5 h-5 mb-1 text-yellow-400" />
                    <span>Upload</span>
                  </label>
                  <input
                    id="principal-photo-input"
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePrincipalPhotoUpload}
                    className="hidden"
                  />
                </div>

                <div className="mt-5 text-center lg:text-left">
                  <h3 className="text-xl font-bold tracking-tight text-white uppercase">
                    {schoolInfo.principalName}
                  </h3>
                  <p className="text-xs font-semibold text-yellow-400 uppercase tracking-widest mt-0.5">
                    Principal & Academic Director
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {schoolInfo.name}
                  </p>
                </div>
              </div>

              {/* Bottom quote snippet */}
              <div className="mt-6 pt-4 border-t border-slate-700 text-xs text-slate-300 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                <span className="italic">"Equipping every student with knowledge and morals for a luminous future."</span>
              </div>
            </div>

            {/* Right Column: Full Principal Welcome Message */}
            <div className="lg:col-span-8 p-6 sm:p-10 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-4 mb-3">
                  <div className="flex items-center gap-2 text-blue-900 font-bold text-xs uppercase tracking-wider font-mono">
                    <span className="w-2 h-2 bg-yellow-500 rounded-full inline-block"></span>
                    <span>Leadership Statement</span>
                  </div>
                  <Quote className="w-8 h-8 text-slate-300 flex-shrink-0" />
                </div>

                <h4 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mb-4">
                  "Welcome to A One Laurel Science School"
                </h4>

                <div className="space-y-3.5 text-slate-600 text-sm leading-relaxed">
                  <p className="font-semibold text-slate-800">
                    Dear Parents, Guardians, and Esteemed Students,
                  </p>

                  <p>
                    It is an immense privilege and joy to welcome you to <strong>{schoolInfo.name}</strong>. In today’s rapidly advancing world, education must transcend traditional memorization. Our core vision is to build an environment where our youth develop intellectual sharpness, scientific inquiry, and unyielding moral dignity.
                  </p>

                  <p>
                    At our school in <strong>{schoolInfo.address}</strong>, we have assembled dedicated teachers who treat each student as their own child. Whether starting in Play Group with phonics and Montessori activities or preparing for <strong>BISE Multan Board Matric Science</strong> examinations, our students receive continuous guidance, weekly assessments, and motivational encouragement.
                  </p>

                  <p>
                    We take immense pride in our board examination achievements—consistently producing students who score <strong>1100+ marks</strong> and secure top merit ranks. Beyond academics, we emphasize Tarbiyah (moral training), Deeni taleem, and physical sports to cultivate balanced personalities who serve our nation with distinction.
                  </p>

                  <p>
                    I warmly invite you to visit our campus, inspect our classrooms and laboratories, and partner with us in shaping your child’s luminous future.
                  </p>
                </div>
              </div>

              {/* Signature & Credentials */}
              <div className="mt-6 pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="text-base font-bold text-slate-900 uppercase">
                    {schoolInfo.principalName}
                  </p>
                  <p className="text-xs text-slate-500">
                    Principal, {schoolInfo.name}
                  </p>
                  <p className="text-xs text-slate-500 font-mono">
                    Phone: {schoolInfo.phone}
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-700 bg-slate-100 px-3 py-1.5 rounded border border-slate-200">
                  <CheckCircle className="w-3.5 h-3.5 text-yellow-600 flex-shrink-0" />
                  <span className="font-semibold uppercase text-[10px] tracking-wider">Parent Consultations Available</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
