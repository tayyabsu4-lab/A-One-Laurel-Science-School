import React from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Trophy,
  Award,
  Sparkles,
  Star,
  CheckCircle2,
  Users,
  BookOpen,
} from 'lucide-react';

export const Achievements: React.FC = () => {
  const { stats, achievements, schoolInfo } = useSchool();

  return (
    <section className="py-16 sm:py-20 bg-[#1e293b] text-white relative overflow-hidden border-y border-slate-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-slate-800 text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            <span>Proven Record of Distinction</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
            Our Achievements & Milestones
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-300">
            Celebrating the academic triumphs and personal breakthroughs of our students.
          </p>
        </div>

        {/* 4 Major School Stats Bar */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {stats.map((stat) => (
            <div
              key={stat.id}
              className="bg-slate-800/80 rounded-lg p-4 sm:p-5 border border-slate-700 text-center"
            >
              <p className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-yellow-400 mb-1 font-mono">
                {stat.value}
              </p>
              <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider mb-1">
                {stat.label}
              </h3>
              {stat.urduLabel && (
                <p className="text-xs font-serif text-slate-300 mb-1 font-bold">
                  {stat.urduLabel}
                </p>
              )}
              <p className="text-[11px] text-slate-400">
                {stat.description}
              </p>
            </div>
          ))}
        </div>

        {/* Board Position Holders Highlight Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {achievements.map((item) => (
            <div
              key={item.id}
              className="bg-slate-800/60 rounded-lg p-5 border border-slate-700 hover:border-yellow-500/40 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold text-slate-900 bg-yellow-400 px-2 py-0.5 rounded uppercase tracking-wider">
                    {item.badge}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    {item.year}
                  </span>
                </div>

                {item.marks && (
                  <div className="mb-3 bg-slate-900 p-2.5 rounded border border-slate-700">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Board Score</span>
                    <span className="text-xl font-extrabold text-yellow-400 font-mono">
                      {item.marks}
                    </span>
                    {item.totalMarks && (
                      <span className="text-xs text-slate-400 font-mono"> / {item.totalMarks}</span>
                    )}
                  </div>
                )}

                <h3 className="text-sm font-bold text-white mb-1">
                  {item.title}
                </h3>

                {item.studentName && (
                  <p className="text-xs font-bold text-yellow-400 mb-1">
                    {item.studentName} {item.fatherName ? `(${item.fatherName})` : ''}
                  </p>
                )}

                <p className="text-xs text-slate-300 leading-relaxed mb-3">
                  {item.description}
                </p>
              </div>

              <div className="pt-2.5 border-t border-slate-700 flex items-center gap-1.5 text-[11px] text-slate-300 font-medium">
                <Star className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                <span>BISE Multan Board Distinction</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
