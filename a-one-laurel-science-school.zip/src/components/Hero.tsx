import React, { useRef } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Sparkles,
  ArrowRight,
  PhoneCall,
  MessageCircle,
  Award,
  CheckCircle2,
  Maximize2,
  Upload,
  BookOpen,
  Atom,
  ShieldCheck,
  Building,
} from 'lucide-react';

export const Hero: React.FC = () => {
  const { schoolInfo, setSchoolPhoto, setActiveImagePreview } = useSchool();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const whatsappCleanNumber = schoolInfo.whatsapp.replace(/[^0-9]/g, '');
  const internationalWhatsApp = whatsappCleanNumber.startsWith('0')
    ? '92' + whatsappCleanNumber.slice(1)
    : whatsappCleanNumber;

  const whatsappUrl = `https://wa.me/${internationalWhatsApp}?text=${encodeURIComponent(
    `Hello, I would like to get information about admission at ${schoolInfo.name}.`
  )}`;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setSchoolPhoto(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const scrollToAdmission = (e: React.MouseEvent) => {
    e.preventDefault();
    const el = document.getElementById('admission-form');
    if (el) {
      const topOffset = 80;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  const scrollToContact = (e: React.MouseEvent) => {
    e.preventDefault();
    const el = document.getElementById('contact');
    if (el) {
      const topOffset = 80;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative pt-28 sm:pt-32 pb-16 lg:pb-24 bg-slate-50 border-b border-slate-200 overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-yellow-200/20 blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-0 -ml-20 w-80 h-80 rounded-full bg-slate-300/20 blur-2xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Top Badges */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-4">
          <span className="inline-flex items-center gap-1.5 py-1 px-3 rounded-full text-[10px] sm:text-xs font-bold uppercase tracking-wider bg-yellow-500 text-slate-900 shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Admissions 2025–2026 Open</span>
          </span>
          <span className="inline-flex items-center gap-1.5 py-1 px-3 rounded-full text-[10px] sm:text-xs font-semibold uppercase tracking-wider bg-white text-slate-800 border border-slate-200 shadow-xs">
            <Award className="w-3.5 h-3.5 text-yellow-600" />
            <span>BISE Multan Board Affiliated</span>
          </span>
          <span className="inline-flex items-center gap-1.5 py-1 px-3 rounded-full text-[10px] sm:text-xs font-semibold uppercase tracking-wider bg-white text-slate-800 border border-slate-200 shadow-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Govt. Punjab Reg (EMIS: {schoolInfo.emisCode})</span>
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Heading, School Intro, CTAs */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              <div className="inline-block mb-1">
                <span className="text-xs font-bold uppercase tracking-[0.25em] text-yellow-600">
                  Established Excellence
                </span>
              </div>
              <h1 className="text-3xl sm:text-4xl xl:text-5xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
                Welcome to{' '}
                <span className="text-[#1e293b]">
                  {schoolInfo.name}
                </span>
              </h1>
              <p className="mt-2 text-xl sm:text-2xl font-serif font-bold text-blue-900 tracking-wide">
                {schoolInfo.urduName}
              </p>
            </div>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl">
              Providing a nurturing environment for the next generation of scientists, leaders, and innovators. Located at{' '}
              <strong className="text-slate-800">{schoolInfo.address}</strong>, we empower students from Play Group to Grade 10 Matric Science with modern labs, qualified faculty, and personal mentorship.
            </p>

            {/* Value Cards matching Professional Polish aesthetic */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="bg-white p-3.5 rounded-lg shadow-xs border border-slate-200">
                <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-1 flex items-center gap-2">
                  <span className="w-2 h-2 bg-yellow-500 rounded-full"></span> Modern Science Labs
                </h3>
                <p className="text-xs text-slate-600">Equipped Physics, Chemistry & Biology laboratory apparatus.</p>
              </div>
              <div className="bg-white p-3.5 rounded-lg shadow-xs border border-slate-200">
                <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-1 flex items-center gap-2">
                  <span className="w-2 h-2 bg-yellow-500 rounded-full"></span> Board Excellence
                </h3>
                <p className="text-xs text-slate-600">100% Matric Board pass rate with top positions in Multan Board.</p>
              </div>
              <div className="bg-white p-3.5 rounded-lg shadow-xs border border-slate-200">
                <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-1 flex items-center gap-2">
                  <span className="w-2 h-2 bg-yellow-500 rounded-full"></span> Character & Tarbiyah
                </h3>
                <p className="text-xs text-slate-600">Islamic values, ethics, and character building alongside academics.</p>
              </div>
              <div className="bg-white p-3.5 rounded-lg shadow-xs border border-slate-200">
                <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-1 flex items-center gap-2">
                  <span className="w-2 h-2 bg-yellow-500 rounded-full"></span> Safe Secure Campus
                </h3>
                <p className="text-xs text-slate-600">CCTV monitored, disciplined, and separate sections for boys & girls.</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                id="hero-apply-btn"
                onClick={scrollToAdmission}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded font-bold text-xs uppercase tracking-wider text-slate-900 bg-yellow-500 hover:bg-yellow-400 shadow-md transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <span>Apply for Admission</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-contact-btn"
                onClick={scrollToContact}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded font-bold text-xs uppercase tracking-wider text-slate-800 bg-white hover:bg-slate-100 border-2 border-slate-700 shadow-xs transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5 text-blue-900" />
                <span>Contact Us</span>
              </button>

              <a
                id="hero-whatsapp-btn"
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded font-bold text-xs uppercase tracking-wider text-white bg-[#25D366] hover:bg-[#20bd5a] shadow-md transition-all hover:scale-[1.02]"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Us</span>
              </a>
            </div>

            {/* Quick Contact snippet */}
            <div className="pt-2 text-xs text-slate-500 flex items-center gap-4">
              <span>Principal: <strong className="text-slate-800 uppercase">{schoolInfo.principalName}</strong></span>
              <span>•</span>
              <span>Helpline: <strong className="text-slate-800 font-mono">{schoolInfo.phone}</strong></span>
            </div>
          </div>

          {/* Right Column: Prominent Real School Photo Card */}
          <div className="lg:col-span-6">
            <div className="relative group">
              <div className="relative bg-white rounded-lg overflow-hidden border border-slate-200 shadow-md">
                {/* Photo Header Bar */}
                <div className="bg-[#1e293b] text-white px-4 py-2.5 flex items-center justify-between text-xs border-b-2 border-yellow-500">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                    <span className="font-bold uppercase tracking-wider text-[11px]">Official School Campus</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      id="hero-photo-zoom-btn"
                      onClick={() => setActiveImagePreview(schoolInfo.photoUrl)}
                      className="p-1 rounded hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                      title="View Fullscreen"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                    <label
                      htmlFor="hero-file-input"
                      className="cursor-pointer inline-flex items-center gap-1 text-slate-900 hover:bg-yellow-400 bg-yellow-500 font-bold px-2 py-0.5 rounded text-[10px] uppercase tracking-wider transition-colors"
                      title="Upload or update with real photo"
                    >
                      <Upload className="w-3 h-3" />
                      <span>Upload Photo</span>
                    </label>
                    <input
                      id="hero-file-input"
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </div>
                </div>

                {/* The Real School Photo - 100% Original and Unaltered */}
                <div
                  className="relative aspect-[4/3] bg-slate-100 overflow-hidden cursor-pointer group/photo flex items-center justify-center"
                  onClick={() => setActiveImagePreview(schoolInfo.photoUrl)}
                  title="Click to view full unedited photo"
                >
                  <img
                    id="hero-school-building-img"
                    src={schoolInfo.photoUrl}
                    alt="A One Laurel Science School Building - Adda Ideal Farm, Jahanian"
                    className="w-full h-full object-cover object-center group-hover/photo:scale-[1.01] transition-transform duration-300"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (!target.src.includes('IMG_E7145.JPG')) {
                        target.src = '/IMG_E7145.JPG';
                      }
                    }}
                  />

                  {/* Overlaid Tag Badges */}
                  <div className="absolute top-3 left-3 bg-[#1e293b]/90 backdrop-blur-xs text-yellow-400 px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider shadow-md border border-yellow-500/40 font-mono">
                    EMIS: {schoolInfo.emisCode}
                  </div>

                  <div className="absolute top-3 right-3 bg-yellow-500 text-slate-900 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shadow-lg">
                    Admissions Open
                  </div>

                  {/* Bottom caption overlay */}
                  <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950/90 via-slate-900/60 to-transparent p-4 text-white">
                    <p className="font-bold text-sm sm:text-base leading-tight uppercase tracking-wide">
                      A One Laurel Science School
                    </p>
                    <p className="text-xs text-slate-300 flex items-center justify-between mt-1">
                      <span>{schoolInfo.address}</span>
                      <span className="text-yellow-400 font-bold uppercase text-[10px] tracking-wider flex items-center gap-1">
                        <Maximize2 className="w-3 h-3" />
                        <span>Click to View Full Photo</span>
                      </span>
                    </p>
                  </div>
                </div>

                {/* Sub-bar with authentic photo badge and school highlights */}
                <div className="p-3 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
                  <div className="flex items-center gap-1.5 text-slate-800 font-bold text-[10px] uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span>100% Original School Photo</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-blue-900 font-semibold uppercase text-[10px] tracking-wider">
                      BISE Multan Board
                    </span>
                    <span className="text-slate-400">•</span>
                    <button
                      type="button"
                      onClick={() => setActiveImagePreview(schoolInfo.photoUrl)}
                      className="text-yellow-600 hover:text-yellow-700 font-bold uppercase text-[10px] tracking-wider underline decoration-yellow-400"
                    >
                      Enlarge Photo →
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
