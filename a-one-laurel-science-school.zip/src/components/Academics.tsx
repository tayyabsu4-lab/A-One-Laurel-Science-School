import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  BookOpen,
  Sparkles,
  GraduationCap,
  Layers,
  ChevronRight,
  CheckCircle2,
  Atom,
} from 'lucide-react';

export const Academics: React.FC = () => {
  const { classes } = useSchool();
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'pre-primary' | 'primary' | 'middle' | 'high'>('all');

  const categories = [
    { id: 'all', label: 'All Levels (PG – 10th)' },
    { id: 'pre-primary', label: 'Pre-Primary (PG, Nursery, Prep)' },
    { id: 'primary', label: 'Primary Wing (Grade 1 – 5)' },
    { id: 'middle', label: 'Middle Wing (Grade 6 – 8)' },
    { id: 'high', label: 'High School (Matric Science 9 & 10)' },
  ];

  const filteredClasses = selectedCategory === 'all'
    ? classes
    : classes.filter((c) => c.category === selectedCategory);

  const scrollToAdmission = (e: React.MouseEvent) => {
    e.preventDefault();
    const el = document.getElementById('admission-form');
    if (el) {
      const topOffset = 80;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  return (
    <section id="academics" className="py-16 sm:py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#1e293b] text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <GraduationCap className="w-3.5 h-3.5 text-yellow-400" />
            <span>Structured Educational Pathway</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Classes & Academic Programs
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-600">
            From early childhood foundational learning to rigorous BISE Multan Board Matric Science preparation.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center justify-center flex-wrap gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat.id}
              id={`academics-tab-${cat.id}`}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`px-3.5 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition-all ${
                selectedCategory === cat.id
                  ? 'bg-yellow-500 text-slate-900 shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Classes Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredClasses.map((item) => (
            <div
              key={item.id}
              id={`class-card-${item.id}`}
              className={`bg-white rounded-lg p-5 border transition-all duration-200 flex flex-col justify-between shadow-sm ${
                item.isHighlight
                  ? 'border-slate-300 border-t-4 border-t-yellow-500'
                  : 'border-slate-200'
              }`}
            >
              <div>
                {/* Card Top Badges */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider bg-slate-100 px-2 py-0.5 rounded font-mono">
                    Age: {item.ageGroup}
                  </span>
                  {item.isHighlight && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-900 bg-yellow-400 px-2 py-0.5 rounded uppercase tracking-wider">
                      <Sparkles className="w-3 h-3 text-slate-900" />
                      <span>Board Year</span>
                    </span>
                  )}
                </div>

                {/* Class Title in English & Urdu */}
                <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                  {item.title}
                </h3>
                {item.urduTitle && (
                  <p className="text-xs font-serif font-bold text-blue-900 mt-0.5 mb-2">
                    {item.urduTitle}
                  </p>
                )}

                <p className="text-[11px] text-slate-500 font-medium mb-2">
                  Curriculum: <span className="text-slate-800 font-semibold">{item.curriculum}</span>
                </p>

                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  {item.description}
                </p>

                {/* Key Subjects */}
                <div className="mb-3">
                  <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block mb-1.5">
                    Core Subjects
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {item.subjects.map((sub, sIdx) => (
                      <span
                        key={sIdx}
                        className="text-[11px] px-2 py-0.5 bg-slate-100 text-slate-700 rounded font-medium"
                      >
                        {sub}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Key Features */}
                <div className="space-y-1.5 pt-2 border-t border-slate-100">
                  {item.features.map((feat, fIdx) => (
                    <div key={fIdx} className="flex items-center gap-2 text-xs text-slate-600">
                      <CheckCircle2 className="w-3.5 h-3.5 text-yellow-600 flex-shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card Footer CTA */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 uppercase tracking-wider">Admissions Active</span>
                <button
                  onClick={scrollToAdmission}
                  className="inline-flex items-center gap-1 text-xs font-bold text-blue-900 hover:text-yellow-600 transition-colors uppercase tracking-wide"
                >
                  <span>Apply Now</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Matric Science Special Banner */}
        <div className="mt-10 bg-[#1e293b] text-white rounded-lg p-6 sm:p-8 shadow-md border border-slate-700 border-t-4 border-yellow-500 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-slate-800 text-yellow-400 text-xs font-bold uppercase tracking-wider border border-yellow-500/30">
              <Atom className="w-3.5 h-3.5 text-yellow-400" />
              <span>BISE Multan Matric Special Science Wing</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold tracking-tight">
              Grade 9th & 10th Matric Science Group
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Specialized science syllabus coaching with complete laboratory experiments in Physics, Chemistry, and Biology. Our round-the-clock test session (3 rounds of revisions and solved past papers) prepares students to score 1100+ marks and secure admissions in top pre-medical and engineering colleges.
            </p>
          </div>
          <button
            onClick={scrollToAdmission}
            className="flex-shrink-0 px-5 py-2.5 rounded bg-yellow-500 hover:bg-yellow-400 text-slate-900 font-bold text-xs uppercase tracking-wider shadow-sm transition-all hover:scale-105"
          >
            Apply for Matric Science
          </button>
        </div>
      </div>
    </section>
  );
};
