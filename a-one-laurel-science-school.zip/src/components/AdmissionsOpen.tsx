import React from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Calendar,
  Clock,
  FileCheck,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Layers,
  HelpCircle,
} from 'lucide-react';

export const AdmissionsOpen: React.FC = () => {
  const { schoolInfo } = useSchool();

  const scrollToAdmission = (e: React.MouseEvent) => {
    e.preventDefault();
    const el = document.getElementById('admission-form');
    if (el) {
      const topOffset = 80;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  return (
    <section id="admissions-open" className="py-16 sm:py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header Banner */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#1e293b] text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>Academic Session {schoolInfo.admissionSession}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Admissions Are Now Open
          </h2>

          <p className="mt-2 text-base sm:text-lg font-bold text-blue-900 uppercase tracking-wide">
            "Give Your Child a Better Future"
          </p>

          <p className="mt-2 text-xs sm:text-sm text-slate-600 max-w-xl mx-auto">
            Empowering students with strong scientific concepts, high moral values, and verified BISE Multan Board Matric excellence. Limited seats available per section.
          </p>
        </div>

        {/* Admission Information Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-8">
          {/* Card 1: Admission Session */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-sm">
            <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-yellow-500 rounded-full inline-block"></span>
              Admission Session
            </h3>
            <p className="text-2xl font-extrabold text-slate-900 mb-2 font-mono">
              {schoolInfo.admissionSession}
            </p>
            <p className="text-xs text-slate-600 leading-relaxed">
              Registrations active for both morning primary and high school secondary shifts. Early registration guarantees preferred class section.
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
              <span>Status: <strong className="text-emerald-700 font-bold uppercase">Active</strong></span>
              <span>Boys & Girls Campus</span>
            </div>
          </div>

          {/* Card 2: Available Classes */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-sm">
            <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-yellow-500 rounded-full inline-block"></span>
              Available Classes
            </h3>
            <p className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              Play Group to Grade 10 (Matric Science)
            </p>
            <ul className="text-xs text-slate-600 space-y-1.5">
              <li className="flex items-center gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 flex-shrink-0" />
                <span>Pre-Primary: Play Group, Nursery, Prep</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 flex-shrink-0" />
                <span>Primary Wing: Grade 1 through Grade 5</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 flex-shrink-0" />
                <span>Middle Wing: Grade 6, Grade 7, Grade 8</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 flex-shrink-0" />
                <span>High School: Grade 9 & 10 Matric Science</span>
              </li>
            </ul>
          </div>

          {/* Card 3: School Timings */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-sm">
            <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-yellow-500 rounded-full inline-block"></span>
              School Timings
            </h3>
            <div className="space-y-2 text-xs text-slate-700 mb-2">
              <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Summer Timings:</span>
                <span className="font-bold text-slate-900">{schoolInfo.schoolTimingSummer}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Winter Timings:</span>
                <span className="font-bold text-slate-900">{schoolInfo.schoolTimingWinter}</span>
              </div>
            </div>
            <p className="text-[11px] text-slate-500">
              Assembly begins 15 minutes before the first period. Friday prayer break observed.
            </p>
          </div>

          {/* Card 4: Admission Requirements */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-sm md:col-span-2">
            <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-yellow-500 rounded-full inline-block"></span>
              Admission Requirements & Documents
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Essential documents required for admission verification
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-slate-700">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>Original & Copy of NADRA B-Form / Birth Certificate</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>Father's / Guardian's National CNIC copy</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>4 recent passport-size blue background student photographs</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>Previous School Leaving Certificate (SLC) for Class 1 to 10</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>Previous Class Report Card / Progress Card</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>Completed and signed School Admission Application Form</span>
              </div>
            </div>
          </div>

          {/* Card 5: Admission Deadline & Concession */}
          <div className="bg-[#1e293b] text-white rounded-lg p-5 border border-slate-700 shadow-md border-t-4 border-yellow-500 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="px-2 py-0.5 rounded bg-yellow-500 text-slate-900 text-[10px] font-bold uppercase tracking-wider">
                  Important Notice
                </span>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Limited Seats</span>
              </div>
              <h3 className="text-base font-bold mb-1">
                Admission Deadline
              </h3>
              <p className="text-xs text-yellow-400 font-mono mb-3">
                {schoolInfo.admissionDeadline}
              </p>
              <div className="p-2.5 rounded bg-slate-800/80 border border-slate-700 text-xs text-slate-300 space-y-1">
                <p className="font-bold text-yellow-400 text-[11px] uppercase tracking-wider">Merit Concessions Available:</p>
                <p className="text-[11px]">• 100% Free Admission for 90%+ Board Position Holders</p>
                <p className="text-[11px]">• Special Fee Concessions for Orphans and Siblings</p>
              </div>
            </div>

            <div className="mt-5">
              <button
                id="admission-open-apply-btn"
                onClick={scrollToAdmission}
                className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded bg-yellow-500 hover:bg-yellow-400 text-slate-900 font-bold text-xs uppercase tracking-wider shadow-sm transition-all hover:scale-[1.02]"
              >
                <span>Apply Online Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Help strip */}
        <div className="bg-white rounded-lg p-3.5 border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-blue-900" />
            <span>Need assistance with the admission procedure? Contact our desk:</span>
          </div>
          <div className="flex items-center gap-3 font-mono">
            <a href={`tel:${schoolInfo.rawPhone}`} className="font-bold text-slate-900 hover:text-yellow-600">
              {schoolInfo.phone}
            </a>
            <span>|</span>
            <span className="text-slate-700 font-sans">{schoolInfo.address}</span>
          </div>
        </div>
      </div>
    </section>
  );
};
