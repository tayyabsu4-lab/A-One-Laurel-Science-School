import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Clock,
  Send,
  CheckCircle2,
  AlertCircle,
  Building,
  Sparkles,
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { schoolInfo } = useSchool();

  const [form, setForm] = useState({
    fullName: '',
    phone: '',
    email: '',
    subject: 'Admission Inquiry',
    message: '',
  });

  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const whatsappCleanNumber = schoolInfo.whatsapp.replace(/[^0-9]/g, '');
  const internationalWhatsApp = whatsappCleanNumber.startsWith('0')
    ? '92' + whatsappCleanNumber.slice(1)
    : whatsappCleanNumber;

  const whatsappUrl = `https://wa.me/${internationalWhatsApp}?text=${encodeURIComponent(
    `Hello, I would like to inquire about ${schoolInfo.name}.`
  )}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName.trim() || !form.phone.trim() || !form.message.trim()) {
      setErrorMessage('Please fill in your name, contact phone, and message.');
      setStatus('error');
      return;
    }

    setStatus('submitting');
    setTimeout(() => {
      setStatus('success');
      setForm({
        fullName: '',
        phone: '',
        email: '',
        subject: 'Admission Inquiry',
        message: '',
      });
      setErrorMessage('');
    }, 400);
  };

  return (
    <section id="contact" className="py-16 sm:py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#1e293b] text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <Phone className="w-3.5 h-3.5 text-yellow-400" />
            <span>Direct Communication & Campus Visits</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Contact Our School
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-600">
            Have questions about admissions, faculty, or curriculum? Call, message, or visit our campus.
          </p>
        </div>

        {/* 4 Contact Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {/* Phone Card */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded bg-[#1e293b] text-yellow-400 flex items-center justify-center mb-3">
                <Phone className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                Phone Number
              </h3>
              <p className="text-base font-bold text-slate-900 mb-1 font-mono">
                {schoolInfo.phone}
              </p>
              <p className="text-[11px] text-slate-500">
                Principal Jam Naseem / Office Helpline
              </p>
            </div>
            <a
              id="contact-call-btn"
              href={`tel:${schoolInfo.rawPhone}`}
              className="mt-4 w-full py-2 px-3 rounded bg-[#1e293b] hover:bg-slate-800 text-yellow-400 text-xs font-bold uppercase tracking-wider text-center block transition-colors border border-yellow-500/20"
            >
              Call Directly
            </a>
          </div>

          {/* WhatsApp Card */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded bg-emerald-600 text-white flex items-center justify-center mb-3">
                <MessageCircle className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                WhatsApp Chat
              </h3>
              <p className="text-base font-bold text-emerald-700 mb-1 font-mono">
                {schoolInfo.whatsapp}
              </p>
              <p className="text-[11px] text-slate-500">
                Instant reply for admission queries & circulars
              </p>
            </div>
            <a
              id="contact-whatsapp-btn"
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 w-full py-2 px-3 rounded bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold uppercase tracking-wider text-center block transition-colors"
            >
              Chat on WhatsApp
            </a>
          </div>

          {/* Email Card */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded bg-slate-100 text-slate-800 flex items-center justify-center mb-3">
                <Mail className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                Email Address
              </h3>
              <p className="text-xs font-bold text-slate-900 mb-1 break-all">
                {schoolInfo.email}
              </p>
              <p className="text-[11px] text-slate-500">
                For administrative correspondence & documents
              </p>
            </div>
            <a
              id="contact-email-btn"
              href={`mailto:${schoolInfo.email}`}
              className="mt-4 w-full py-2 px-3 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold uppercase tracking-wider text-center block transition-colors"
            >
              Send Email
            </a>
          </div>

          {/* Campus Location Card */}
          <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded bg-slate-100 text-slate-800 flex items-center justify-center mb-3">
                <MapPin className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                Campus Location
              </h3>
              <p className="text-xs font-bold text-slate-900 mb-1">
                {schoolInfo.address}
              </p>
              <p className="text-[11px] text-slate-500">
                Tehsil Jahanian, Punjab
              </p>
            </div>
            <a
              id="contact-map-directions-btn"
              href="https://maps.google.com/?q=Jahanian+Punjab+Pakistan"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 w-full py-2 px-3 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold uppercase tracking-wider text-center block transition-colors"
            >
              View on Map
            </a>
          </div>
        </div>

        {/* Contact Form & Campus Information Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Form */}
          <div className="lg:col-span-7 bg-white rounded-lg p-6 sm:p-8 border border-slate-200 shadow-xs">
            <h3 className="text-xl font-bold uppercase tracking-wider text-slate-900 mb-1">
              Send Us a Message
            </h3>
            <p className="text-xs text-slate-500 mb-5">
              Fill out this quick form and our school admission counselor will get in touch with you shortly.
            </p>

            {status === 'success' && (
              <div className="mb-5 p-3 rounded bg-emerald-50 border border-emerald-300 text-emerald-900 flex items-center gap-2 text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Thank you! Your message has been received. Our team will contact you soon.</span>
              </div>
            )}

            {status === 'error' && (
              <div className="mb-5 p-3 rounded bg-red-50 border border-red-300 text-red-900 flex items-center gap-2 text-xs">
                <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="contact-form-name" className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Your Name *
                  </label>
                  <input
                    id="contact-form-name"
                    type="text"
                    required
                    value={form.fullName}
                    onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                    placeholder="Enter your full name"
                    className="w-full px-3 py-2 rounded border border-slate-300 text-xs focus:outline-none focus:ring-1 focus:ring-yellow-500"
                  />
                </div>

                <div>
                  <label htmlFor="contact-form-phone" className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Contact Phone Number *
                  </label>
                  <input
                    id="contact-form-phone"
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="e.g. 0347-XXXXXXX"
                    className="w-full px-3 py-2 rounded border border-slate-300 text-xs focus:outline-none focus:ring-1 focus:ring-yellow-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="contact-form-email" className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Email Address (Optional)
                  </label>
                  <input
                    id="contact-form-email"
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2 rounded border border-slate-300 text-xs focus:outline-none focus:ring-1 focus:ring-yellow-500"
                  />
                </div>

                <div>
                  <label htmlFor="contact-form-subject" className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Subject / Topic
                  </label>
                  <select
                    id="contact-form-subject"
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    className="w-full px-3 py-2 rounded border border-slate-300 text-xs focus:outline-none focus:ring-1 focus:ring-yellow-500"
                  >
                    <option value="Admission Inquiry">New Admission Inquiry</option>
                    <option value="Fee Structure">Fee Structure & Concession</option>
                    <option value="Matric Science Coaching">Matric Science Coaching</option>
                    <option value="Job Application">Teacher Recruitment / Careers</option>
                    <option value="General Question">General Question</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="contact-form-message" className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Message / Inquiry Details *
                </label>
                <textarea
                  id="contact-form-message"
                  rows={4}
                  required
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Tell us what you would like to know about A One Laurel Science School..."
                  className="w-full px-3 py-2 rounded border border-slate-300 text-xs focus:outline-none focus:ring-1 focus:ring-yellow-500"
                />
              </div>

              <button
                id="contact-form-submit-btn"
                type="submit"
                disabled={status === 'submitting'}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded bg-yellow-500 hover:bg-yellow-400 disabled:opacity-50 text-slate-900 font-bold uppercase tracking-wider text-xs shadow-xs transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{status === 'submitting' ? 'Sending Message...' : 'Send Message'}</span>
              </button>
            </form>
          </div>

          {/* Right: Visiting Hours & Directions Info */}
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-[#1e293b] text-white rounded-lg p-6 shadow-xs border border-slate-700">
              <div className="flex items-center gap-2 text-yellow-400 font-bold text-xs uppercase tracking-wider mb-3 font-mono">
                <Clock className="w-3.5 h-3.5" />
                <span>Campus Visiting & Office Hours</span>
              </div>

              <h4 className="text-base font-bold uppercase tracking-wider mb-3">
                Office & Admission Timings
              </h4>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-700">
                  <span>Monday – Thursday:</span>
                  <span className="font-semibold text-white">8:00 AM – 2:00 PM</span>
                </div>
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-700">
                  <span>Friday (Jumma):</span>
                  <span className="font-semibold text-white">8:00 AM – 12:30 PM</span>
                </div>
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-700">
                  <span>Saturday:</span>
                  <span className="font-semibold text-white">8:00 AM – 1:30 PM</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Sunday:</span>
                  <span className="text-yellow-400 font-semibold">Weekly Holiday (Closed)</span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-700">
                <p className="text-[11px] text-slate-400">
                  Parents wishing to meet Principal <strong>{schoolInfo.principalName}</strong> personally are advised to visit between 10:00 AM and 1:00 PM on working days.
                </p>
              </div>
            </div>

            {/* Campus Landmark Card */}
            <div className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs">
              <div className="flex items-center gap-3 mb-2.5">
                <div className="w-9 h-9 rounded bg-slate-100 text-slate-800 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm uppercase tracking-wider">
                    How to Reach the Campus
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Adda Ideal Farm, Tehsil Jahanian
                  </p>
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                The school is prominently located right at <strong>Adda Ideal Farm</strong> on the main access road in Tehsil Jahanian. Look for the grand blue signboard with Pakistan flag entrance gate. Ample parking space available for parents during school drop and pick-up hours.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
