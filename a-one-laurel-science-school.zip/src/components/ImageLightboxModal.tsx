import React, { useEffect } from 'react';
import { useSchool } from '../context/SchoolContext';
import { X, ZoomIn, ChevronLeft, ChevronRight } from 'lucide-react';

export const ImageLightboxModal: React.FC = () => {
  const { activeImagePreview, setActiveImagePreview, gallery } = useSchool();

  // Distinct image URLs for navigation
  const uniqueImages = Array.from(new Set(gallery.map((item) => item.imageUrl)));
  const currentIndex = activeImagePreview ? uniqueImages.indexOf(activeImagePreview) : -1;
  const hasMultipleImages = uniqueImages.length > 1;

  const handlePrev = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!hasMultipleImages) return;
    const newIndex = currentIndex <= 0 ? uniqueImages.length - 1 : currentIndex - 1;
    setActiveImagePreview(uniqueImages[newIndex]);
  };

  const handleNext = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!hasMultipleImages) return;
    const newIndex = currentIndex >= uniqueImages.length - 1 ? 0 : currentIndex + 1;
    setActiveImagePreview(uniqueImages[newIndex]);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setActiveImagePreview(null);
      } else if (e.key === 'ArrowLeft' && hasMultipleImages) {
        handlePrev();
      } else if (e.key === 'ArrowRight' && hasMultipleImages) {
        handleNext();
      }
    };
    if (activeImagePreview) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeImagePreview, currentIndex, uniqueImages, hasMultipleImages]);

  if (!activeImagePreview) return null;

  const currentItem = gallery.find((item) => item.imageUrl === activeImagePreview);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/92 backdrop-blur-md animate-in fade-in duration-200"
      onClick={() => setActiveImagePreview(null)}
    >
      <div
        className="relative max-w-5xl w-full max-h-[92vh] flex flex-col items-center justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top controls */}
        <div className="w-full flex items-center justify-between pb-2 text-white">
          <div className="flex items-center gap-2">
            <ZoomIn className="w-4 h-4 text-yellow-400" />
            <span className="text-xs font-bold tracking-wide">
              {currentItem?.title || 'High Resolution Campus Photo'}
            </span>
          </div>
          <button
            id="close-lightbox-btn"
            onClick={() => setActiveImagePreview(null)}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            title="Close Lightbox"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Image Display & Nav Arrows */}
        <div className="relative rounded-xl overflow-hidden shadow-2xl border border-white/20 bg-black/60 flex items-center justify-center max-h-[75vh] w-full">
          {hasMultipleImages && (
            <button
              onClick={handlePrev}
              id="lightbox-prev-btn"
              className="absolute left-3 top-1/2 -translate-y-1/2 z-10 p-2.5 rounded-full bg-slate-900/80 hover:bg-yellow-500 hover:text-slate-900 text-white transition-all shadow-md"
              title="Previous Photo"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}

          <img
            src={activeImagePreview}
            alt={currentItem?.title || 'School Fullscreen View'}
            className="max-h-[75vh] w-auto max-w-full object-contain rounded-lg"
            referrerPolicy="no-referrer"
            onError={(e) => {
              const target = e.currentTarget;
              if (!target.src.includes('IMG_E7145.JPG')) {
                target.src = '/IMG_E7145.JPG';
              }
            }}
          />

          {hasMultipleImages && (
            <button
              onClick={handleNext}
              id="lightbox-next-btn"
              className="absolute right-3 top-1/2 -translate-y-1/2 z-10 p-2.5 rounded-full bg-slate-900/80 hover:bg-yellow-500 hover:text-slate-900 text-white transition-all shadow-md"
              title="Next Photo"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Caption & Thumbnails */}
        {currentItem && (
          <div className="w-full text-center mt-2.5 px-4">
            <p className="text-xs text-slate-300 font-medium line-clamp-2">
              {currentItem.caption}
            </p>
          </div>
        )}

        <p className="mt-2 text-[10px] text-slate-400">
          {hasMultipleImages ? (
            <>
              Use <kbd className="px-1 py-0.5 rounded bg-white/10 text-white font-mono text-[9px]">←</kbd> <kbd className="px-1 py-0.5 rounded bg-white/10 text-white font-mono text-[9px]">→</kbd> to navigate • <kbd className="px-1 py-0.5 rounded bg-white/10 text-white font-mono text-[9px]">ESC</kbd> to close
            </>
          ) : (
            <>
              Press <kbd className="px-1 py-0.5 rounded bg-white/10 text-white font-mono text-[9px]">ESC</kbd> or click anywhere to close
            </>
          )}
        </p>
      </div>
    </div>
  );
};
