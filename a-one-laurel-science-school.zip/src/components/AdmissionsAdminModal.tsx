import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  X,
  ClipboardList,
  Search,
  Filter,
  Download,
  Trash2,
  Printer,
  CheckCircle,
  Clock,
  User,
  Phone,
  Layers,
} from 'lucide-react';
import { AdmissionApplication } from '../types';

export const AdmissionsAdminModal: React.FC = () => {
  const { admissions, updateAdmissionStatus, deleteAdmission, isAdminModalOpen, setIsAdminModalOpen, schoolInfo } = useSchool();
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('All');
  const [selectedApp, setSelectedApp] = useState<AdmissionApplication | null>(null);

  if (!isAdminModalOpen) return null;

  const filteredAdmissions = admissions.filter((app) => {
    const matchesSearch =
      app.studentFullName.toLowerCase().includes(search.toLowerCase()) ||
      app.fatherName.toLowerCase().includes(search.toLowerCase()) ||
      app.referenceNumber.toLowerCase().includes(search.toLowerCase()) ||
      app.parentPhone.includes(search);
    const matchesClass = classFilter === 'All' || app.classApplyingFor === classFilter;
    return matchesSearch && matchesClass;
  });

  const exportCSV = () => {
    if (admissions.length === 0) return;
    const headers = [
      'Reference No',
      'Student Name',
      'Father Name',
      'Gender',
      'DOB',
      'Class Applied',
      'Parent Phone',
      'WhatsApp',
      'Address',
      'Submission Date',
      'Status',
    ];
    const rows = admissions.map((a) => [
      `"${a.referenceNumber}"`,
      `"${a.studentFullName}"`,
      `"${a.fatherName}"`,
      `"${a.gender}"`,
      `"${a.dob}"`,
      `"${a.classApplyingFor}"`,
      `"${a.parentPhone}"`,
      `"${a.whatsappNumber}"`,
      `"${a.address}"`,
      `"${a.submittedAt}"`,
      `"${a.status}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `admissions_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-5xl w-full shadow-2xl border border-slate-200 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-slate-900">
                School Admissions Desk & Applicant Register
              </h3>
              <p className="text-xs text-slate-500">
                {admissions.length} Total Online Applications Logged
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {admissions.length > 0 && (
              <button
                onClick={exportCSV}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
            )}
            <button
              onClick={() => setIsAdminModalOpen(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="py-4 flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by student, father, or phone..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-xs text-slate-500 font-medium">Filter Class:</span>
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="All">All Classes</option>
              <option value="Grade 9 (Matric Science)">Grade 9 (Matric Science)</option>
              <option value="Grade 10 (Matric Science)">Grade 10 (Matric Science)</option>
              <option value="Grade 8">Grade 8</option>
              <option value="Grade 7">Grade 7</option>
              <option value="Grade 6">Grade 6</option>
              <option value="Grade 5">Grade 5</option>
              <option value="Play Group">Play Group</option>
              <option value="Nursery">Nursery</option>
              <option value="Prep (Kindergarten)">Prep</option>
            </select>
          </div>
        </div>

        {/* Applications List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 border border-slate-100 rounded-2xl">
          {filteredAdmissions.length === 0 ? (
            <div className="text-center py-16 text-slate-400 text-sm">
              <ClipboardList className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p className="font-bold text-slate-600">No applications found</p>
              <p className="text-xs text-slate-400 mt-1">
                When visitors fill out the Online Admission Form, their details will appear here.
              </p>
            </div>
          ) : (
            filteredAdmissions.map((app) => (
              <div
                key={app.id}
                className="p-4 hover:bg-slate-50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                      {app.referenceNumber}
                    </span>
                    <span className="text-xs text-slate-400">{app.submittedAt}</span>
                  </div>

                  <h4 className="text-base font-bold text-slate-900">
                    {app.studentFullName}{' '}
                    <span className="text-xs text-slate-500 font-normal">
                      s/d of {app.fatherName}
                    </span>
                  </h4>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
                    <span className="font-semibold text-blue-800">
                      Class: {app.classApplyingFor}
                    </span>
                    <span>•</span>
                    <span>Gender: {app.gender}</span>
                    <span>•</span>
                    <span>Phone: {app.parentPhone}</span>
                    <span>•</span>
                    <span>Address: {app.address}</span>
                  </div>
                </div>

                {/* Right controls */}
                <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
                  <select
                    value={app.status}
                    onChange={(e) => updateAdmissionStatus(app.id, e.target.value as any)}
                    className="text-xs font-bold px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white"
                  >
                    <option value="Pending Review">Pending Review</option>
                    <option value="Interview Scheduled">Interview Scheduled</option>
                    <option value="Approved">Approved</option>
                    <option value="Admission Granted">Admission Granted</option>
                  </select>

                  <button
                    onClick={() => setSelectedApp(app)}
                    className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-50"
                    title="View Application Slip"
                  >
                    <Printer className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm(`Delete application for ${app.studentFullName}?`)) {
                        deleteAdmission(app.id);
                      }
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50"
                    title="Delete Application"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Slip detail preview */}
        {selectedApp && (
          <div className="mt-4 p-4 rounded-2xl bg-blue-50/70 border border-blue-200 text-xs flex items-center justify-between">
            <div>
              <p className="font-bold text-slate-900">
                Application: {selectedApp.studentFullName} ({selectedApp.referenceNumber})
              </p>
              <p className="text-slate-600">
                Father: {selectedApp.fatherName} | Phone: {selectedApp.parentPhone} | Class: {selectedApp.classApplyingFor}
              </p>
            </div>
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 rounded-lg bg-blue-700 text-white font-bold"
            >
              Print
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
