import React, { useState, useEffect } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  MessageCircle,
  ArrowUp,
  FileText,
  Settings,
} from 'lucide-react';

export const FloatingActions: React.FC = () => {
  const { schoolInfo, setIsEditModalOpen } = useSchool();
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const whatsappCleanNumber = schoolInfo.whatsapp.replace(/[^0-9]/g, '');
  const internationalWhatsApp = whatsappCleanNumber.startsWith('0')
    ? '92' + whatsappCleanNumber.slice(1)
    : whatsappCleanNumber;

  const whatsappUrl = `https://wa.me/${internationalWhatsApp}?text=${encodeURIComponent(
    `Hello, I would like to get information about admission at ${schoolInfo.name}.`
  )}`;

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToAdmission = () => {
    const el = document.getElementById('admission-form');
    if (el) {
      const topOffset = 80;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-3 pointer-events-none">
      {/* Scroll to top button */}
      {showScrollTop && (
        <button
          id="scroll-to-top-btn"
          onClick={scrollToTop}
          className="pointer-events-auto p-3 rounded-full bg-slate-900/90 hover:bg-slate-900 text-white shadow-lg backdrop-blur-xs transition-all hover:scale-110 active:scale-95"
          aria-label="Scroll to top"
          title="Scroll to Top"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

      {/* Floating Apply Now Pill on Mobile & Tablet */}
      <button
        id="floating-apply-pill-btn"
        onClick={scrollToAdmission}
        className="pointer-events-auto inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-yellow-500 hover:bg-yellow-400 text-slate-900 font-bold uppercase tracking-wider text-xs shadow-xl transition-all hover:scale-105 active:scale-95 border border-yellow-400 sm:hidden"
      >
        <FileText className="w-4 h-4" />
        <span>Apply Online</span>
      </button>

      {/* STICKY WHATSAPP BUTTON (Mandated in User Prompt) */}
      <a
        id="sticky-whatsapp-floating-btn"
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="pointer-events-auto group relative flex items-center gap-2.5 bg-[#25D366] hover:bg-[#20bd5a] text-white px-4 py-3 rounded-full shadow-2xl transition-all duration-300 hover:scale-105 active:scale-95 border-2 border-white/80"
        aria-label="Chat with A One Laurel Science School on WhatsApp"
        title="Chat on WhatsApp"
      >
        <MessageCircle className="w-6 h-6 fill-current flex-shrink-0" />
        <span className="font-bold text-sm tracking-wide hidden sm:inline">
          WhatsApp Us
        </span>
        {/* Pulse ring */}
        <span className="absolute -inset-1 rounded-full bg-emerald-400 opacity-30 group-hover:opacity-60 animate-ping pointer-events-none" />
      </a>
    </div>
  );
};
