import React from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  GraduationCap,
  Building,
  Monitor,
  FlaskConical,
  BookOpen,
  Trophy,
  Mic,
  ShieldCheck,
  Sparkles,
  Award,
  CheckCircle,
} from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  GraduationCap,
  Building,
  Monitor,
  FlaskConical,
  BookOpen,
  Trophy,
  Mic,
  ShieldCheck,
  Sparkles,
  Award,
};

export const Facilities: React.FC = () => {
  const { facilities } = useSchool();

  return (
    <section id="facilities" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#1e293b] text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>Campus Infrastructure & Student Care</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            School Facilities
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-600">
            A comprehensive, healthy, and modern learning ecosystem designed to foster intellectual growth and well-being.
          </p>
        </div>

        {/* 10 Facilities Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {facilities.map((fac, index) => {
            const IconComponent = iconMap[fac.iconName] || Sparkles;
            return (
              <div
                key={fac.id}
                id={`facility-card-${fac.id}`}
                className="bg-white rounded-lg p-5 border border-slate-200 shadow-sm hover:border-slate-300 transition-all duration-200 flex flex-col justify-between group"
              >
                <div>
                  {/* Top Bar with Icon & Tag */}
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div className="w-10 h-10 rounded bg-slate-100 text-slate-800 group-hover:bg-yellow-500 group-hover:text-slate-900 transition-colors flex items-center justify-center flex-shrink-0">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                      {fac.tag}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 leading-snug">
                    {fac.title}
                  </h3>

                  {fac.urduTitle && (
                    <p className="text-xs font-serif font-bold text-blue-900 mt-0.5 mb-2">
                      {fac.urduTitle}
                    </p>
                  )}

                  <p className="text-xs text-slate-600 leading-relaxed mb-3">
                    {fac.description}
                  </p>

                  {/* Bullet points */}
                  <div className="space-y-1 pt-2 border-t border-slate-100">
                    {fac.bulletPoints.map((bp, bpIdx) => (
                      <div key={bpIdx} className="flex items-start gap-1.5 text-xs text-slate-700">
                        <CheckCircle className="w-3.5 h-3.5 text-yellow-600 flex-shrink-0 mt-0.5" />
                        <span>{bp}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span>FACILITY #{index + 1}</span>
                  <span className="text-emerald-700 font-bold uppercase tracking-wider">Available</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
