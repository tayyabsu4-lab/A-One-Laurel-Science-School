import React from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Target,
  Compass,
  HeartHandshake,
  CheckCircle2,
  Sparkles,
  Maximize2,
  GraduationCap,
  ShieldCheck,
  Microscope,
} from 'lucide-react';

export const AboutUs: React.FC = () => {
  const { schoolInfo, setActiveImagePreview } = useSchool();

  const values = [
    {
      title: 'Academic & Science Excellence',
      description: 'Focusing on deep concept comprehension over rote learning, preparing young minds for higher competitive studies in science and medicine.',
      icon: Microscope,
    },
    {
      title: 'Islamic & Moral Character',
      description: 'Instilling honesty, modesty, respect for elders, and sound ethical conscience grounded in Deeni and cultural values.',
      icon: HeartHandshake,
    },
    {
      title: 'Discipline & Punctuality',
      description: 'Cultivating healthy daily study routines, strict attendance adherence, and self-motivated responsibility.',
      icon: ShieldCheck,
    },
    {
      title: 'Holistic Student Development',
      description: 'Balancing rigorous classroom instruction with physical fitness, spoken communication, and co-curricular creativity.',
      icon: GraduationCap,
    },
  ];

  const whyChoosePoints = [
    'Registered institution with Punjab Government Education Department (EMIS: 364420802).',
    'Official affiliation with BISE Multan Board for Matriculation Science Examinations.',
    'Consistent track record of students achieving 1100+ marks and top Tehsil positions.',
    'Equipped Physics, Chemistry, and Biology laboratories for practical science training.',
    'Dedicated Computer Lab with modern systems ensuring computer literacy from early grades.',
    'Experienced, qualified, and compassionate teaching faculty dedicated to every child.',
    'Secure, spacious campus with boundary wall, 24/7 security, and safe learning environment.',
    'Affordable fee structure with generous merit and need-based scholarships.',
  ];

  return (
    <section id="about" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#1e293b] text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>Discover Our Heritage & Vision</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            About Our School
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-600">
            Nurturing scholars, thinkers, and ethical leaders at Adda Ideal Farm, Jahanian.
          </p>
        </div>

        {/* Introduction & School Image Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-14">
          {/* Left: Introduction */}
          <div className="lg:col-span-7 space-y-4">
            <div className="border-l-4 border-yellow-500 pl-4">
              <span className="text-xs font-bold uppercase tracking-widest text-slate-500 font-mono">
                Official School Profile
              </span>
              <h3 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-0.5">
                {schoolInfo.name}
              </h3>
              <p className="text-base font-serif text-blue-900 font-bold mt-0.5">
                {schoolInfo.urduName}
              </p>
            </div>

            <p className="text-slate-600 leading-relaxed text-sm">
              <strong>{schoolInfo.name}</strong> was established with a profound mission: to bring quality science education and moral mentorship to the children of Adda Ideal Farm, Jahanian, and surrounding communities.
            </p>

            <p className="text-slate-600 leading-relaxed text-sm">
              Registered under the <strong>Government of Punjab School Education Department</strong> and affiliated with the <strong>Board of Intermediate & Secondary Education (BISE) Multan</strong>, our school provides a complete academic pathway from Play Group, Nursery, and Prep through Primary, Middle, and Matric Science (Grades 9 & 10).
            </p>

            <p className="text-slate-600 leading-relaxed text-sm">
              Under the visionary leadership of Principal <strong>{schoolInfo.principalName}</strong>, we emphasize high board exam performance, individual student attention, practical scientific experimentation, and Islamic ethical values.
            </p>

            <div className="pt-2 flex flex-wrap gap-3 text-xs text-slate-700">
              <div className="bg-slate-50 px-3 py-2 rounded border border-slate-200">
                <span className="block text-slate-400 font-bold uppercase text-[10px] tracking-wider">EMIS Registration</span>
                <span className="font-bold text-slate-900 font-mono">{schoolInfo.emisCode}</span>
              </div>
              <div className="bg-slate-50 px-3 py-2 rounded border border-slate-200">
                <span className="block text-slate-400 font-bold uppercase text-[10px] tracking-wider">Board Affiliation</span>
                <span className="font-bold text-slate-900">BISE Multan</span>
              </div>
              <div className="bg-slate-50 px-3 py-2 rounded border border-slate-200">
                <span className="block text-slate-400 font-bold uppercase text-[10px] tracking-wider">Location</span>
                <span className="font-bold text-slate-900">{schoolInfo.address}</span>
              </div>
            </div>
          </div>

          {/* Right: Real School Photo Showcase */}
          <div className="lg:col-span-5">
            <div className="relative group rounded-lg overflow-hidden shadow-sm border border-slate-200 bg-slate-100">
              <div className="relative aspect-[4/3] cursor-pointer" onClick={() => setActiveImagePreview(schoolInfo.photoUrl)}>
                <img
                  src={schoolInfo.photoUrl}
                  alt="A One Laurel Science School Building"
                  className="w-full h-full object-cover object-center group-hover:scale-101 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.src.includes('IMG_E7145.JPG')) {
                      target.src = '/IMG_E7145.JPG';
                    }
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-4 text-white">
                  <div>
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-yellow-500 text-slate-900 px-2 py-0.5 rounded uppercase tracking-wider mb-1">
                      Campus View
                    </span>
                    <p className="font-bold text-sm">
                      A One Laurel Science School Campus
                    </p>
                    <p className="text-xs text-slate-300">
                      Adda Ideal Farm, Jahanian
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveImagePreview(schoolInfo.photoUrl);
                    }}
                    className="ml-auto p-1.5 bg-slate-900/60 hover:bg-slate-900 text-white rounded transition-colors"
                    title="Fullscreen"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Verified School Photo Info Bar */}
              <div className="p-3 bg-white border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wide">
                    100% Original Photo • No Alteration
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveImagePreview(schoolInfo.photoUrl)}
                  className="text-[11px] font-bold text-yellow-600 hover:text-yellow-700 uppercase tracking-wider underline decoration-yellow-400"
                >
                  Full Resolution →
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mission & Vision Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-14">
          {/* Mission Card */}
          <div className="bg-white rounded-lg p-6 border border-slate-200 shadow-sm border-t-4 border-yellow-500">
            <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-yellow-500 rounded-full inline-block"></span>
              Our Mission
            </h3>
            <p className="text-slate-600 leading-relaxed text-sm">
              To deliver accessible, high-standard science education and ethical upbringing that unlocks every child's academic potential. We nurture students to become critical thinkers, knowledgeable problem solvers, and conscientious citizens ready to excel in board examinations and future careers.
            </p>
          </div>

          {/* Vision Card */}
          <div className="bg-white rounded-lg p-6 border border-slate-200 shadow-sm border-t-4 border-slate-700">
            <h3 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-yellow-500 rounded-full inline-block"></span>
              Our Vision
            </h3>
            <p className="text-slate-600 leading-relaxed text-sm">
              To be the benchmark center of academic distinction in Tehsil Jahanian—where modern scientific inquiry merges seamlessly with moral character, inspiring students to lead with integrity, knowledge, and service to humanity.
            </p>
          </div>
        </div>

        {/* Our Values */}
        <div className="mb-14">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-yellow-600 font-mono">
              Core Principles
            </span>
            <h3 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
              Our Core Values
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              The fundamental pillars guiding daily education and student life at A One Laurel Science School.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {values.map((v, idx) => {
              return (
                <div
                  key={idx}
                  className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs"
                >
                  <h4 className="text-blue-900 font-bold text-xs uppercase tracking-wider mb-1 flex items-center gap-2">
                    <span className="w-2 h-2 bg-yellow-500 rounded-full inline-block"></span>
                    {v.title}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {v.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Why Choose Our School */}
        <div className="bg-[#1e293b] text-white rounded-lg p-6 sm:p-10 shadow-md border border-slate-700 border-t-4 border-yellow-500">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-slate-800 text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
              <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
              <span>Distinct Advantage</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold tracking-tight mb-3">
              Why Choose A One Laurel Science School?
            </h3>
            <p className="text-slate-300 text-xs sm:text-sm mb-6 max-w-2xl leading-relaxed">
              We understand parents desire the highest quality schooling with strong moral foundations. Here is what makes our school the preferred choice for families in Adda Ideal Farm:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {whyChoosePoints.map((point, index) => (
                <div key={index} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-yellow-500 flex-shrink-0 mt-0.5" />
                  <span className="text-xs sm:text-sm text-slate-200">{point}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
