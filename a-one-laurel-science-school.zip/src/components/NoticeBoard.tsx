import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Bell,
  Calendar,
  Tag,
  Search,
  AlertCircle,
  FileText,
  Printer,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { NoticeItem } from '../types';

export const NoticeBoard: React.FC = () => {
  const { notices, schoolInfo } = useSchool();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeNotice, setActiveNotice] = useState<NoticeItem | null>(null);

  const categories = ['All', 'Admissions', 'Exams', 'Results', 'Meetings', 'Events', 'General'];

  const filteredNotices = notices.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.urduTitle && item.urduTitle.includes(searchQuery));
    return matchesCategory && matchesSearch;
  });

  const getCategoryBadgeClass = (category: string) => {
    switch (category) {
      case 'Admissions':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Exams':
        return 'bg-amber-100 text-amber-900 border-amber-200';
      case 'Results':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Meetings':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Events':
        return 'bg-pink-100 text-pink-800 border-pink-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <section id="notices" className="py-16 sm:py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#1e293b] text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <Bell className="w-3.5 h-3.5 text-yellow-400" />
            <span>Official Circulars & Announcements</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Notice Board & Circulars
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-600">
            Keep updated with official schedules, examination circulars, holidays, and academic announcements.
          </p>
        </div>

        {/* Search & Category Tabs */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-8">
          {/* Category Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`notice-cat-${cat}`}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-yellow-500 text-slate-900 shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Bar */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search circulars or notices..."
              className="w-full pl-9 pr-3 py-1.5 rounded bg-white border border-slate-300 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-yellow-500"
            />
          </div>
        </div>

        {/* Notices Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredNotices.map((notice) => (
            <div
              key={notice.id}
              id={`notice-card-${notice.id}`}
              onClick={() => setActiveNotice(notice)}
              className="bg-white rounded-lg p-5 border border-slate-200 shadow-xs hover:shadow-sm hover:border-slate-300 transition-all flex flex-col justify-between cursor-pointer group"
            >
              <div>
                {/* Top info */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${getCategoryBadgeClass(notice.category)}`}>
                    {notice.category}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    <span>{notice.date}</span>
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-900 transition-colors leading-snug mb-1">
                  {notice.title}
                </h3>

                {notice.urduTitle && (
                  <p className="text-xs font-serif font-bold text-blue-900 mb-2">
                    {notice.urduTitle}
                  </p>
                )}

                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-3">
                  {notice.description}
                </p>
              </div>

              {/* Card Footer */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-900 font-bold uppercase tracking-wider group-hover:text-yellow-600">
                <span>Read Circular</span>
                <ChevronRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>

        {filteredNotices.length === 0 && (
          <div className="text-center py-10 bg-white rounded-lg border border-slate-200 p-6">
            <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-700">No notices found</p>
            <p className="text-xs text-slate-500 mt-1">Try adjusting your search query or selected category filter.</p>
          </div>
        )}

        {/* Notice Detail Modal */}
        {activeNotice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
            <div className="bg-white rounded-lg p-6 max-w-2xl w-full shadow-2xl border border-slate-300 max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="flex items-start justify-between pb-3 border-b border-slate-100 mb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${getCategoryBadgeClass(activeNotice.category)}`}>
                      {activeNotice.category}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">Date: {activeNotice.date}</span>
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
                    {activeNotice.title}
                  </h3>
                  {activeNotice.urduTitle && (
                    <p className="text-xs font-serif font-bold text-blue-900">
                      {activeNotice.urduTitle}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => setActiveNotice(null)}
                  className="text-slate-400 hover:text-slate-600 font-bold text-base p-1 ml-4"
                >
                  ✕
                </button>
              </div>

              {/* Official notice body */}
              <div className="bg-slate-50 p-4 rounded border border-slate-200 mb-5 text-xs text-slate-700 leading-relaxed space-y-2">
                <p className="font-bold text-slate-900 uppercase tracking-wider">
                  {schoolInfo.name} — Office of the Principal
                </p>
                <p className="whitespace-pre-line text-slate-700 leading-relaxed">
                  {activeNotice.description}
                </p>
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-500">
                  <p>Campus: {schoolInfo.address}</p>
                  <p>For inquiries: {schoolInfo.phone} | Principal: {schoolInfo.principalName}</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <button
                  onClick={handlePrint}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold uppercase tracking-wider"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Circular</span>
                </button>
                <button
                  onClick={() => setActiveNotice(null)}
                  className="px-4 py-1.5 rounded bg-yellow-500 hover:bg-yellow-400 text-slate-900 text-xs font-bold uppercase tracking-wider shadow-xs"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
