import React from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  GraduationCap,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Clock,
  ShieldCheck,
  Award,
  ChevronRight,
  Heart,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { schoolInfo, setIsEditModalOpen, setIsAdminModalOpen } = useSchool();

  const whatsappCleanNumber = schoolInfo.whatsapp.replace(/[^0-9]/g, '');
  const internationalWhatsApp = whatsappCleanNumber.startsWith('0')
    ? '92' + whatsappCleanNumber.slice(1)
    : whatsappCleanNumber;

  const whatsappUrl = `https://wa.me/${internationalWhatsApp}?text=${encodeURIComponent(
    `Hello, I would like to get information about admission at ${schoolInfo.name}.`
  )}`;

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const topOffset = 80;
      const pos = el.getBoundingClientRect().top + window.pageYOffset - topOffset;
      window.scrollTo({ top: pos, behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#1e293b] text-slate-300 pt-16 pb-12 border-t border-slate-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 pb-10 border-b border-slate-700">
          {/* Column 1: School Identity & Credentials */}
          <div className="lg:col-span-4 space-y-3.5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded bg-slate-800 text-yellow-400 flex items-center justify-center font-bold border border-yellow-500/30">
                <GraduationCap className="w-6 h-6 text-yellow-400" />
              </div>
              <div>
                <h3 className="font-extrabold text-base sm:text-lg text-white tracking-tight leading-tight">
                  {schoolInfo.name}
                </h3>
                <p className="text-xs font-serif text-yellow-400 font-bold mt-0.5">
                  {schoolInfo.urduName}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Dedicated to academic superiority, scientific inquiry, and character development in a secure and caring campus. Registered with Govt of Punjab and affiliated with BISE Multan Board.
            </p>

            <div className="space-y-1 pt-1 text-[11px]">
              <div className="flex items-center gap-2 text-slate-300">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>Punjab Govt Education Dept (EMIS: {schoolInfo.emisCode})</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Award className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                <span>Board of Intermediate & Secondary Education Multan</span>
              </div>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => scrollTo('home')}
                  className="hover:text-yellow-400 transition-colors flex items-center gap-1 text-slate-400"
                >
                  <ChevronRight className="w-3 h-3 text-yellow-500" />
                  <span>Home</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('about')}
                  className="hover:text-yellow-400 transition-colors flex items-center gap-1 text-slate-400"
                >
                  <ChevronRight className="w-3 h-3 text-yellow-500" />
                  <span>About Us</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('admissions-open')}
                  className="hover:text-yellow-400 transition-colors flex items-center gap-1 text-slate-400"
                >
                  <ChevronRight className="w-3 h-3 text-yellow-500" />
                  <span>Admissions</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('principal')}
                  className="hover:text-yellow-400 transition-colors flex items-center gap-1 text-slate-400"
                >
                  <ChevronRight className="w-3 h-3 text-yellow-500" />
                  <span>Principal Message</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('academics')}
                  className="hover:text-yellow-400 transition-colors flex items-center gap-1 text-slate-400"
                >
                  <ChevronRight className="w-3 h-3 text-yellow-500" />
                  <span>Classes & Academics</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('facilities')}
                  className="hover:text-yellow-400 transition-colors flex items-center gap-1 text-slate-400"
                >
                  <ChevronRight className="w-3 h-3 text-yellow-500" />
                  <span>School Facilities</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('gallery')}
                  className="hover:text-yellow-400 transition-colors flex items-center gap-1 text-slate-400"
                >
                  <ChevronRight className="w-3 h-3 text-yellow-500" />
                  <span>Campus Gallery</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('notices')}
                  className="hover:text-yellow-400 transition-colors flex items-center gap-1 text-slate-400"
                >
                  <ChevronRight className="w-3 h-3 text-yellow-500" />
                  <span>Notice Board</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Academic Wings */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Academic Levels
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>Play Group, Nursery & Prep</li>
              <li>Primary Wing (Grades 1 to 5)</li>
              <li>Middle Wing (Grades 6 to 8)</li>
              <li>Matric Science Part-I (9th Class)</li>
              <li>Matric Science Part-II (10th Class)</li>
              <li className="pt-2 text-yellow-400 font-bold uppercase tracking-wider text-[11px]">
                Weekly Test Series & BISE Prep
              </li>
            </ul>
          </div>

          {/* Column 4: Contact & Office Info */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Campus Contact
            </h4>
            <div className="space-y-2 text-xs text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-yellow-400 mt-0.5 flex-shrink-0" />
                <span>{schoolInfo.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                <a href={`tel:${schoolInfo.rawPhone}`} className="hover:text-white font-mono">
                  {schoolInfo.phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white font-mono">
                  {schoolInfo.whatsapp} (WhatsApp)
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                <a href={`mailto:${schoolInfo.email}`} className="hover:text-white">
                  {schoolInfo.email}
                </a>
              </div>
              <div className="pt-2 text-xs text-slate-400">
                <span className="block font-bold text-slate-300 uppercase tracking-wider text-[10px]">Principal:</span>
                <span className="text-white">{schoolInfo.principalName}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright & management buttons */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>
            © {new Date().getFullYear()} {schoolInfo.name}. All rights reserved.
          </p>

          <div className="flex items-center gap-3">
            <button
              id="footer-edit-placeholders-btn"
              onClick={() => setIsEditModalOpen(true)}
              className="text-yellow-400 hover:text-yellow-300 uppercase tracking-wider font-bold text-[11px] transition-colors"
            >
              Edit School Info
            </button>
            <span className="text-slate-600">•</span>
            <button
              id="footer-admissions-portal-btn"
              onClick={() => setIsAdminModalOpen(true)}
              className="text-yellow-400 hover:text-yellow-300 uppercase tracking-wider font-bold text-[11px] transition-colors"
            >
              Admissions Desk Portal
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
