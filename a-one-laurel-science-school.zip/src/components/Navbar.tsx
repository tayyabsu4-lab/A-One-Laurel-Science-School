import React, { useState, useEffect } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Phone,
  MessageCircle,
  MapPin,
  Menu,
  X,
  GraduationCap,
  Sparkles,
  ClipboardList,
  Edit3,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { schoolInfo, admissions, setIsEditModalOpen, setIsAdminModalOpen } = useSchool();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      // Simple active section spy
      const sections = ['home', 'admissions-open', 'about', 'principal', 'academics', 'facilities', 'gallery', 'notices', 'contact'];
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 140 && rect.bottom >= 140) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home', id: 'home' },
    { name: 'About', href: '#about', id: 'about' },
    { name: 'Admissions', href: '#admissions-open', id: 'admissions-open' },
    { name: 'Academics', href: '#academics', id: 'academics' },
    { name: 'Facilities', href: '#facilities', id: 'facilities' },
    { name: 'Gallery', href: '#gallery', id: 'gallery' },
    { name: 'Notices', href: '#notices', id: 'notices' },
    { name: 'Contact', href: '#contact', id: 'contact' },
  ];

  const whatsappCleanNumber = schoolInfo.whatsapp.replace(/[^0-9]/g, '');
  const internationalWhatsApp = whatsappCleanNumber.startsWith('0')
    ? '92' + whatsappCleanNumber.slice(1)
    : whatsappCleanNumber;

  const whatsappUrl = `https://wa.me/${internationalWhatsApp}?text=${encodeURIComponent(
    `Hello, I would like to get information about admission at ${schoolInfo.name}.`
  )}`;

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      const topOffset = 90;
      const elementPosition = target.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - topOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#1e293b] text-white border-b-4 border-yellow-500 shadow-lg transition-all duration-300">
      {/* Top Notification Bar */}
      <div className="bg-[#0f172a] text-slate-300 text-xs py-1.5 px-4 sm:px-6 border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Left: EMIS & Affiliation badges */}
          <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
            <span className="inline-flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded text-yellow-400 font-mono font-bold border border-yellow-500/30">
              <span>EMIS:</span> {schoolInfo.emisCode}
            </span>
            <span className="hidden md:inline-flex items-center gap-1 text-slate-300">
              <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
              <span>Reg: Punjab Govt | BISE Multan</span>
            </span>
            <span className="hidden lg:inline-flex items-center gap-1 text-slate-400">
              <MapPin className="w-3.5 h-3.5 text-yellow-400" />
              <span>{schoolInfo.address}</span>
            </span>
          </div>

          {/* Right: Quick Call, WhatsApp, and Edit Placeholders */}
          <div className="flex items-center gap-2 sm:gap-3 ml-auto">
            <a
              id="top-bar-call-btn"
              href={`tel:${schoolInfo.rawPhone}`}
              className="inline-flex items-center gap-1 text-slate-200 hover:text-yellow-400 transition-colors"
              title="Call School"
            >
              <Phone className="w-3.5 h-3.5 text-yellow-400" />
              <span className="font-semibold">{schoolInfo.phone}</span>
            </a>

            <span className="text-slate-600">|</span>

            <a
              id="top-bar-whatsapp-btn"
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">WhatsApp</span>
            </a>

            {/* Quick Admin/Edit trigger */}
            <button
              id="top-bar-edit-btn"
              onClick={() => setIsEditModalOpen(true)}
              className="inline-flex items-center gap-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-yellow-400 px-2 py-0.5 rounded border border-yellow-500/40 transition-colors font-medium"
              title="Edit school info placeholders"
            >
              <Edit3 className="w-3 h-3" />
              <span className="hidden sm:inline">Edit Info</span>
            </button>

            {admissions.length > 0 && (
              <button
                id="top-bar-admissions-desk-btn"
                onClick={() => setIsAdminModalOpen(true)}
                className="inline-flex items-center gap-1 text-[11px] bg-yellow-500 hover:bg-yellow-400 text-slate-900 px-2 py-0.5 rounded font-bold uppercase shadow-xs"
              >
                <ClipboardList className="w-3 h-3" />
                <span>Desk ({admissions.length})</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className={`transition-all duration-200 ${isScrolled ? 'py-2 sm:py-2.5' : 'py-3 sm:py-3.5'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-4">
          {/* Logo & School Name */}
          <a
            id="nav-brand-logo"
            href="#home"
            onClick={(e) => scrollToSection(e, '#home')}
            className="flex items-center gap-3 group text-left"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full overflow-hidden shadow-md border-2 border-yellow-500 group-hover:scale-105 transition-transform flex-shrink-0 bg-slate-900 flex items-center justify-center">
              <img
                src={schoolInfo.photoUrl || '/IMG_E7145.JPG'}
                alt={schoolInfo.name}
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base sm:text-lg lg:text-xl text-white tracking-tight uppercase leading-tight group-hover:text-yellow-400 transition-colors">
                  {schoolInfo.name}
                </span>
              </div>
              <p className="text-[10px] sm:text-xs font-semibold text-yellow-400 uppercase tracking-widest leading-none mt-1">
                Excellence in Education & Character
              </p>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-xs font-medium uppercase tracking-wide">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.id}
                  id={`nav-link-${link.id}`}
                  href={link.href}
                  onClick={(e) => scrollToSection(e, link.href)}
                  className={`px-3 py-1.5 rounded-sm text-xs font-semibold tracking-wider transition-all ${
                    isActive
                      ? 'text-yellow-400 bg-slate-800 font-bold'
                      : 'text-slate-200 hover:text-yellow-400 hover:bg-slate-800/60'
                  }`}
                >
                  {link.name}
                </a>
              );
            })}
          </nav>

          {/* Right Action CTAs */}
          <div className="hidden sm:flex items-center gap-2.5">
            <a
              id="nav-apply-btn"
              href="#admission-form"
              onClick={(e) => scrollToSection(e, '#admission-form')}
              className="inline-flex items-center justify-center px-4 py-2 rounded-sm text-xs font-bold uppercase tracking-wider text-[#1e293b] bg-yellow-500 hover:bg-yellow-400 shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              Apply Now
            </a>
          </div>

          {/* Mobile Hamburger Toggle Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <a
              id="mobile-nav-apply-btn"
              href="#admission-form"
              onClick={(e) => scrollToSection(e, '#admission-form')}
              className="text-xs font-bold px-3 py-1.5 rounded-sm text-[#1e293b] bg-yellow-500 uppercase tracking-wider sm:hidden"
            >
              Apply Now
            </a>
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded text-slate-200 hover:bg-slate-800 hover:text-yellow-400 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#1e293b] border-t border-slate-700 shadow-2xl px-4 py-4 max-h-[85vh] overflow-y-auto">
          <div className="flex flex-col gap-1 pb-3 border-b border-slate-700">
            {navLinks.map((link) => (
              <a
                key={link.id}
                id={`mobile-nav-${link.id}`}
                href={link.href}
                onClick={(e) => scrollToSection(e, link.href)}
                className={`px-4 py-2.5 rounded text-sm font-semibold uppercase tracking-wider transition-colors ${
                  activeSection === link.id
                    ? 'bg-slate-800 text-yellow-400 font-bold'
                    : 'text-slate-200 hover:bg-slate-800'
                }`}
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="pt-3 flex flex-col gap-2">
            <a
              id="mobile-drawer-apply-btn"
              href="#admission-form"
              onClick={(e) => scrollToSection(e, '#admission-form')}
              className="w-full text-center py-2.5 rounded font-bold uppercase tracking-wider text-[#1e293b] bg-yellow-500 hover:bg-yellow-400 shadow-sm text-xs"
            >
              Apply Now
            </a>
            <div className="grid grid-cols-2 gap-2 mt-1">
              <a
                id="mobile-drawer-call-btn"
                href={`tel:${schoolInfo.rawPhone}`}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded bg-slate-800 border border-slate-700 text-slate-200 font-bold text-xs hover:bg-slate-700"
              >
                <Phone className="w-4 h-4 text-yellow-400" />
                <span>Call Us</span>
              </a>
              <a
                id="mobile-drawer-whatsapp-btn"
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
