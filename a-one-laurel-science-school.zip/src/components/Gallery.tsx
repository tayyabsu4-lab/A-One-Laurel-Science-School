import React, { useState, useRef } from 'react';
import { useSchool } from '../context/SchoolContext';
import {
  Image as ImageIcon,
  Maximize2,
  Plus,
  Upload,
  Sparkles,
  Camera,
  CheckCircle,
  Building,
  Award,
  Flag,
  ShieldCheck,
  MapPin,
  Phone,
} from 'lucide-react';

export const Gallery: React.FC = () => {
  const { gallery, addGalleryImage, setActiveImagePreview, schoolInfo } = useSchool();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'Campus' | 'Science & Lab' | 'Classrooms' | 'Activities' | 'Sports' | 'Events'>('Campus');
  const [newCaption, setNewCaption] = useState('');
  const [newImageDataUrl, setNewImageDataUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const categories = ['All', 'Campus'];

  const filteredGallery = selectedCategory === 'All'
    ? gallery
    : gallery.filter((item) => item.category === selectedCategory);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setNewImageDataUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddPhotoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newImageDataUrl) return;
    addGalleryImage({
      title: newTitle.trim() || 'New School Photo',
      category: newCategory,
      imageUrl: newImageDataUrl,
      caption: newCaption.trim() || 'Photo from A One Laurel Science School.',
      date: 'Uploaded Today',
    });
    setNewTitle('');
    setNewCaption('');
    setNewImageDataUrl('');
    setShowAddModal(false);
  };

  return (
    <section id="gallery" className="py-16 sm:py-20 bg-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#1e293b] text-yellow-400 text-xs font-bold uppercase tracking-wider mb-3 border border-yellow-500/30">
            <Camera className="w-3.5 h-3.5 text-yellow-400" />
            <span>Official Campus Photos & Tour</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            School Photo Gallery
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-600">
            Real photographic views of A-One Laurel Boys and Girls High School, Adda Ideal Farm, Jahanian.
          </p>
        </div>

        {/* Official School Photo Showcase - 100% Original and Unaltered */}
        <div className="mb-14 bg-slate-50 border border-slate-200 rounded-xl p-5 sm:p-7 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-yellow-500 text-slate-900 text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded">
                  Official Photograph
                </span>
                <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                  Official Campus Photo (اصل اسکول تصویر)
                </h3>
              </div>
              <p className="text-xs text-slate-600 mt-1">
                Authentic, unedited campus photograph of A One Laurel Science School at Adda Ideal Farm, Jahanian.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="gallery-zoom-main-photo-btn"
                onClick={() => setActiveImagePreview(schoolInfo.photoUrl)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded bg-yellow-500 hover:bg-yellow-400 text-slate-900 text-xs font-bold uppercase tracking-wider shadow-xs transition-colors"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Fullscreen Zoom</span>
              </button>

              <button
                id="gallery-add-photo-btn-top"
                onClick={() => setShowAddModal(true)}
                className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded bg-[#1e293b] text-yellow-400 hover:bg-slate-800 text-xs font-bold uppercase tracking-wider shadow-xs transition-colors border border-yellow-500/30 flex-shrink-0"
              >
                <Plus className="w-4 h-4 text-yellow-400" />
                <span>Add / Upload Photo</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* Main Authentic Photo Container */}
            <div
              className="lg:col-span-7 relative bg-white rounded-lg border border-slate-300 overflow-hidden shadow-sm group cursor-pointer"
              onClick={() => setActiveImagePreview(schoolInfo.photoUrl)}
              title="Click to view fullscreen in high resolution"
            >
              <div className="relative aspect-[4/3] bg-slate-200 overflow-hidden flex items-center justify-center">
                <img
                  src={schoolInfo.photoUrl}
                  alt="A One Laurel Science School Building - Adda Ideal Farm, Jahanian"
                  className="w-full h-full object-cover group-hover:scale-[1.01] transition-transform duration-300"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.src.includes('IMG_E7145.JPG')) {
                      target.src = '/IMG_E7145.JPG';
                    }
                  }}
                />

                <div className="absolute top-3 left-3 bg-[#1e293b]/90 text-yellow-400 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded shadow-md border border-yellow-500/40">
                  100% Original Photo
                </div>

                <div className="absolute top-3 right-3 p-1.5 rounded-full bg-slate-900/80 text-white backdrop-blur-xs group-hover:bg-slate-900 transition-colors">
                  <Maximize2 className="w-4 h-4" />
                </div>

                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950/90 via-slate-900/60 to-transparent p-4 text-white">
                  <p className="font-bold text-sm leading-tight uppercase">
                    A One Laurel Science School - Main Elevation
                  </p>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Adda Ideal Farm, Tehsil Jahanian, District Khanewal
                  </p>
                </div>
              </div>
            </div>

            {/* Photo Campus Verified Facts */}
            <div className="lg:col-span-5 space-y-3">
              <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs">
                <div className="flex items-center gap-2 text-blue-900 mb-1">
                  <Award className="w-4 h-4 text-yellow-500 flex-shrink-0" />
                  <span className="font-bold text-xs uppercase tracking-wider">
                    Academic Excellence on Signboard
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  The official campus signboard highlights BISE Multan Board affiliation, Admissions Open, and Sobia Hanif securing <strong>1111 / 1200 marks</strong> in Matric 2025.
                </p>
              </div>

              <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs">
                <div className="flex items-center gap-2 text-blue-900 mb-1">
                  <Flag className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span className="font-bold text-xs uppercase tracking-wider">
                    Pakistan National Flag Entrance
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  The secure campus entrance shutter gate is painted with the green and white national flag and crescent star, leading into the school grounds.
                </p>
              </div>

              <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs">
                <div className="flex items-center gap-2 text-blue-900 mb-1">
                  <ShieldCheck className="w-4 h-4 text-blue-900 flex-shrink-0" />
                  <span className="font-bold text-xs uppercase tracking-wider">
                    EMIS Code: 364420802
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Officially registered with the School Education Department Punjab, offering science laboratories, computer IT lab, and dedicated staff.
                </p>
              </div>

              <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-xs">
                <div className="flex items-center gap-2 text-blue-900 mb-1">
                  <Phone className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span className="font-bold text-xs uppercase tracking-wider">
                    Principal & Helpline
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-mono">
                  Principal: Jam Naseem • Call: 0347 8856741
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Filter Pills and Add Photo button */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-8">
          <div className="flex items-center gap-2 flex-wrap">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`gallery-tab-${cat.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition-all ${
                  selectedCategory === cat
                    ? 'bg-yellow-500 text-slate-900 shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <button
            id="gallery-add-photo-btn-bottom"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded bg-[#1e293b] text-yellow-400 hover:bg-slate-800 text-xs font-bold uppercase tracking-wider shadow-xs transition-colors border border-yellow-500/30"
          >
            <Plus className="w-3.5 h-3.5 text-yellow-400" />
            <span>Upload Photo</span>
          </button>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredGallery.map((item, index) => {
            const isOfficialBuilding = item.imageUrl === schoolInfo.photoUrl || item.imageUrl.includes('photo-') || item.imageUrl.includes('IMG_E7145') || item.imageUrl.includes('school-building');
            return (
              <div
                key={item.id}
                id={`gallery-item-${item.id}`}
                className="group relative bg-slate-100 rounded-lg overflow-hidden border border-slate-200 hover:border-yellow-500/60 transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer"
                onClick={() => setActiveImagePreview(item.imageUrl)}
              >
                {/* Image display */}
                <div className="w-full overflow-hidden bg-slate-200 aspect-[4/3]">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover object-center group-hover:scale-101 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (!target.src.includes('IMG_E7145.JPG')) {
                        target.src = '/IMG_E7145.JPG';
                      }
                    }}
                  />
                </div>

                {/* Top Category Badge */}
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                  <span className="bg-[#1e293b]/90 backdrop-blur-xs text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border border-slate-700">
                    {item.category}
                  </span>
                  {isOfficialBuilding && (
                    <span className="bg-yellow-500 text-slate-900 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded flex items-center gap-1 shadow-xs">
                      <Sparkles className="w-3 h-3 text-slate-900" />
                      <span>Official School Photo</span>
                    </span>
                  )}
                </div>

                {/* Zoom Icon Button */}
                <div className="absolute top-2.5 right-2.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="p-1.5 rounded bg-slate-900/80 text-white backdrop-blur-xs hover:bg-slate-900">
                    <Maximize2 className="w-3.5 h-3.5" />
                  </div>
                </div>

                {/* Bottom Caption Overlay */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/95 via-slate-950/75 to-transparent p-3.5 sm:p-4 text-white">
                  <h3 className="font-bold text-xs sm:text-sm leading-snug group-hover:text-yellow-400 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5 line-clamp-2 leading-relaxed">
                    {item.caption}
                  </p>
                  {item.date && (
                    <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">
                      {item.date}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Add Photo Modal */}
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
            <div className="bg-white rounded-lg p-6 max-w-lg w-full shadow-2xl border border-slate-300">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <div className="flex items-center gap-2">
                  <Camera className="w-4 h-4 text-blue-900" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900">Add / Upload School Photo</h3>
                </div>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="text-slate-400 hover:text-slate-600 font-bold p-1 text-xs"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleAddPhotoSubmit} className="space-y-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Select Image File *
                  </label>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    required
                    className="w-full text-xs text-slate-600 file:mr-3 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-[10px] file:font-bold file:uppercase file:bg-slate-100 file:text-slate-800 hover:file:bg-slate-200 cursor-pointer border border-slate-300 rounded p-1.5"
                  />
                  {newImageDataUrl && (
                    <div className="mt-2 w-28 h-20 rounded overflow-hidden border border-slate-300 bg-slate-100">
                      <img src={newImageDataUrl} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Photo Title
                  </label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. Science Laboratory Session or Sports Gala"
                    className="w-full px-3 py-2 rounded border border-slate-300 text-xs focus:ring-1 focus:ring-yellow-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Category
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded border border-slate-300 text-xs focus:ring-1 focus:ring-yellow-500 focus:outline-none"
                  >
                    <option value="Campus">Campus & Building</option>
                    <option value="Science & Lab">Science & Lab</option>
                    <option value="Classrooms">Classrooms</option>
                    <option value="Activities">Student Activities</option>
                    <option value="Sports">Sports</option>
                    <option value="Events">School Events</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Caption / Description
                  </label>
                  <textarea
                    rows={2}
                    value={newCaption}
                    onChange={(e) => setNewCaption(e.target.value)}
                    placeholder="Provide a brief description of this photo..."
                    className="w-full px-3 py-2 rounded border border-slate-300 text-xs focus:ring-1 focus:ring-yellow-500 focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-3 py-1.5 rounded border border-slate-300 text-xs font-bold uppercase tracking-wider text-slate-700 hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!newImageDataUrl}
                    className="px-4 py-1.5 rounded bg-yellow-500 hover:bg-yellow-400 disabled:opacity-50 text-slate-900 text-xs font-bold uppercase tracking-wider shadow-xs"
                  >
                    Upload Photo
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
