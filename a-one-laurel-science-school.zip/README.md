# A One Laurel Science School - Website

Official website of **A One Laurel Science School (Boys & Girls High School)**, Adda Ideal Farm, Tehsil Jahanian, District Khanewal.
- Registered with Government of Punjab (EMIS Code: `364420802`)
- Affiliated with BISE Multan Board

---

## 🚀 Quick Start (Local Development)

### 1. Requirements
- Node.js (version 18 or 20+)
- npm (comes bundled with Node.js)

### 2. Installation & Running
```bash
# 1. Install dependencies
npm install

# 2. Run local development server
npm run dev
```
Open your browser at `http://localhost:3000` (or the port displayed in your terminal).

---

## 📦 Production Build (for Any Hosting Platform)

To create the compiled, static production files:

```bash
npm run build
```

This generates a **`dist/`** folder containing all HTML, CSS, JavaScript, and images ready to be hosted anywhere.

---

## 🌐 Hosting & Deployment Options

### Option 1: Netlify (Easiest - Drag and Drop)
1. Run `npm run build` to generate the `dist` folder.
2. Go to [app.netlify.com](https://app.netlify.com).
3. Drag and drop the `dist` folder directly onto Netlify.
4. Your website is live with a free SSL certificate! You can also connect your own custom domain (e.g., `www.aonelaurel.edu.pk` or `.com`).

### Option 2: Vercel
1. Push this project code to your GitHub account (or use Google AI Studio's **Export to GitHub**).
2. Go to [vercel.com](https://vercel.com) and click **"Add New Project"**.
3. Import your GitHub repository.
4. Framework Preset: **Vite**
5. Click **Deploy**. Vercel will automatically build and publish your site with instant updates whenever you push code.

### Option 3: cPanel / Traditional Shared Hosting
1. Run `npm run build` on your computer.
2. Open your hosting cPanel and go to **File Manager**.
3. Navigate to the `public_html` directory.
4. Upload all files and folders located **inside** the `dist/` folder directly into `public_html`.
5. Your website will be live on your domain immediately.

### Option 4: Deploy Directly from Google AI Studio
1. In the Google AI Studio top-right menu, click **Deploy to Cloud Run**.
2. Select or connect your Google Cloud account.
3. AI Studio will handle the build, containerization, and hosting automatically.
